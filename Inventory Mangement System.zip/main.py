"""
Inventory Management System - Main Application
Author: Your Name
Date: 2025-06-08
"""

import streamlit as st
import sys
from pathlib import Path

# Add src directory to path for imports
sys.path.append(str(Path(__file__).parent / "src"))

from src.components.sidebar import create_sidebar
from src.pages import data_entry, dashboard, reports, download_center, settings
from src.utils.helpers import initialize_session_state, load_custom_css
from src.services.backup_service import create_backup_directories
import config

# Page configuration
st.set_page_config(
    page_title="Inventory Management System",
    page_icon="📦",
    layout="wide",
    initial_sidebar_state="expanded"
)

def main():
    """Main application function"""
    
    # Initialize application
    initialize_session_state()
    create_backup_directories()
    load_custom_css()
    
    # Application header
    st.title("📦 Inventory Management System")
    st.markdown("---")
    
    # Create sidebar navigation
    selected_page = create_sidebar()
    
    # Route to selected page
    if selected_page == "📊 Dashboard":
        dashboard.show_dashboard()
    elif selected_page == "📝 Data Entry":
        data_entry.show_data_entry()
    elif selected_page == "📈 Reports & Analytics":
        reports.show_reports()
    elif selected_page == "💾 Download Center":
        download_center.show_download_center()
    elif selected_page == "⚙️ Settings":
        settings.show_settings()
    
    # Footer
    st.markdown("---")
    col1, col2, col3 = st.columns([1, 2, 1])
    with col2:
        st.markdown(
            "<div style='text-align: center; color: #666;'>"
            f"Inventory Management System v{config.APP_VERSION} | "
            f"Last Updated: {st.session_state.get('last_update', 'Never')}"
            "</div>",
            unsafe_allow_html=True
        )

if __name__ == "__main__":
    main()