# Inventory Management System

A comprehensive web-based inventory management system built with Streamlit that integrates with Excel for seamless data management and real-time analytics.

## Features

### 🏢 Daily Operations Management
- **Opening Stock Entry**: Set daily opening stock levels
- **Sales Recording**: Multi-channel sales tracking (Amazon FBA/Easyship, Flipkart, Others)
- **Purchase Management**: Record raw material and packaging purchases
- **Production Tracking**: Log packaging operations and production batches
- **Returns Processing**: Handle returns with good/bad stock categorization
- **Stock Adjustments**: Physical count reconciliation and adjustments

### 📊 Real-time Dashboard
- **Live KPI Metrics**: Stock value, sales performance, low stock alerts
- **Interactive Charts**: Stock levels, sales trends, channel performance
- **Stock Status Monitoring**: Critical/low stock alerts and notifications
- **Business Analytics**: Product performance and contribution analysis

### 📈 Advanced Analytics & Reporting
- **Demand Forecasting**: 7-day demand predictions
- **Business Insights**: Top products, best channels, peak sales patterns
- **Smart Recommendations**: Automated reorder suggestions and optimization tips
- **Comprehensive Reports**: Detailed analytics with export capabilities

### 💾 Data Management
- **Excel Integration**: Seamless read/write operations with existing Excel files
- **Bulk Upload**: CSV/Excel bulk data import with validation
- **Multiple Export Formats**: Excel, CSV, PDF export options
- **Automated Backups**: Scheduled and manual backup functionality
- **Data Validation**: Comprehensive business rule validation

### ⚙️ System Features
- **Multi-sheet Support**: Handle complex Excel workbooks
- **User-friendly Interface**: Intuitive forms and navigation
- **Real-time Updates**: Live data synchronization
- **Audit Trail**: Complete transaction logging
- **Error Handling**: Robust error management and recovery

## Installation

### Prerequisites
- Python 3.8 or higher
- pip (Python package installer)

### Step 1: Clone or Download the Project
```bash
# If using Git
git clone <repository-url>
cd inventory_management_system

# Or download and extract the ZIP file
```

### Step 2: Create Virtual Environment (Recommended)
```bash
# Create virtual environment
python -m venv inventory_env

# Activate virtual environment
# On Windows:
inventory_env\Scripts\activate

# On macOS/Linux:
source inventory_env/bin/activate
```

### Step 3: Install Dependencies
```bash
pip install -r requirements.txt
```

### Step 4: Setup Directory Structure
```bash
# Create necessary directories
mkdir -p data/templates data/uploads data/exports logs static/css static/images
```

### Step 5: Configuration Setup
1. Copy your existing Excel stock report to `data/uploads/stock_report.xlsx`
2. Modify `config.py` if needed to match your Excel structure
3. Optional: Add your logo to `static/images/logo.png`

## Quick Start

### 1. Launch the Application
```bash
streamlit run main.py
```

The application will open in your default web browser at `http://localhost:8501`

### 2. Initial Setup
1. **Upload Excel File**: Go to Settings and upload your existing Excel stock report
2. **Verify Data**: Check the Dashboard to ensure data is loading correctly
3. **Test Entry**: Try a small data entry to verify functionality

### 3. Daily Workflow
1. **Morning**: Enter opening stock via Data Entry → Daily Operations
2. **Throughout Day**: Record sales, purchases, production as they occur
3. **Evening**: Review Dashboard for performance and alerts
4. **Download Reports**: Use Download Center for daily/weekly reports

## Usage Guide

### Data Entry Portal

#### Daily Operations
- **Opening Stock**: Set starting inventory for the day
- **Sales Entry**: Record sales by channel with automatic stock deduction
- **Purchase Entry**: Log raw material and packaging purchases
- **Production Entry**: Track manufacturing and packaging operations
- **Returns Processing**: Handle customer returns and quality issues
- **Stock Adjustments**: Reconcile physical counts with system records

#### Product Management
- Add new products and variants
- Update product information and pricing
- Manage FNSKU codes and packaging details

#### Quick Entry
- Rapid data entry for common operations
- Preset templates for frequent transactions
- Batch operations for efficiency

#### Bulk Upload
- CSV/Excel file import
- Data validation and error reporting
- Bulk operations for large datasets

### Dashboard & Analytics

#### Real-time Monitoring
- Current stock levels by product
- Sales performance metrics
- Low stock and critical alerts
- Channel-wise performance analysis

#### Business Intelligence
- Sales trend analysis
- Product contribution reports
- Demand forecasting
- Automated recommendations

### Download Center
- Generate reports in multiple formats
- Schedule automated exports
- Historical data downloads
- Backup file management

## File Structure Explained

```
inventory_management_system/
├── main.py                    # Application entry point
├── config.py                  # Configuration settings
├── requirements.txt           # Python dependencies
├── README.md                 # This documentation
│
├── data/                     # Data storage
│   ├── templates/           # Excel templates
│   ├── uploads/             # User uploaded files
│   └── exports/             # Generated reports
│
├── src/                      # Source code
│   ├── components/          # UI components
│   ├── pages/               # Page modules
│   ├── services/            # Business logic
│   ├── models/              # Data models
│   └── utils/               # Utility functions
│
├── static/                   # Static assets
├── tests/                    # Test files
└── logs/                     # Application logs
```

## Configuration

### Excel File Setup
Ensure your Excel file has these sheets:
- `stock sheet`: Main inventory data
- `Return`: Returns tracking
- `Packaging`: Packaging operations
- `Cartoons report`: Packaging materials
- `Packging`: Alternative packaging data

### Column Mapping
The system expects specific columns in your Excel file. Key columns include:
- `Row Labels`: Product identifiers
- `Sum of Sum of Units Ordered`: Order quantities
- `Physical Stock Count`: Current stock levels
- Sales columns by channel (Amazon FBA, Easyship, Flipkart, Others)
- Returns columns (Good stock, Bad stock)

### Customization
Modify `config.py` to adjust:
- Product weights and packaging sizes
- Sales channels and validation rules
- Dashboard thresholds and alerts
- File paths and backup settings

## Troubleshooting

### Common Issues

#### Excel File Not Loading
- **Problem**: Error reading Excel file
- **Solution**: 
  1. Ensure file is not open in Excel
  2. Check file permissions (read/write access)
  3. Verify file path in `config.py`
  4. Try copying file to `data/uploads/` directory

#### Data Validation Errors
- **Problem**: Data entry rejected
- **Solution**:
  1. Check required fields are filled
  2. Verify numeric values are within valid ranges
  3. Ensure dates are not in the future
  4. Confirm product weights match available options

#### Performance Issues
- **Problem**: Slow loading or responses
- **Solution**:
  1. Clear browser cache
  2. Restart the application
  3. Check Excel file size (recommend < 50MB)
  4. Close other applications using memory

#### Import/Export Errors
- **Problem**: Cannot import or export data
- **Solution**:
  1. Check file format (Excel, CSV supported)
  2. Verify file is not corrupted
  3. Ensure adequate disk space
  4. Check file permissions

### Getting Help
1. Check the logs in `logs/app.log` for detailed error messages
2. Verify your Python environment has all required packages
3. Ensure your Excel file structure matches the expected format
4. Try the validation features to identify data issues

## Advanced Features

### Automated Backups
- Configure automatic backup schedules
- Cloud storage integration (AWS S3, Google Cloud)
- Version control for Excel files

### API Integration
- Amazon MWS/SP-API for automated sales data
- Flipkart API integration
- Third-party logistics integration

### Multi-user Support
- User authentication and authorization
- Role-based access control
- Audit trails and user activity logs

### Mobile Access
- Responsive design for mobile devices
- Progressive Web App (PWA) capabilities
- Offline data entry with sync

## Performance Optimization

### For Large Datasets
- Enable data pagination
- Use database backend instead of Excel
- Implement caching strategies
- Optimize chart rendering

### Production Deployment
- Use production WSGI server
- Configure proper logging
- Set up monitoring and alerts
- Implement backup strategies

## Security Considerations

### Data Protection
- Keep Excel files in secure directories
- Regular backup to secure locations
- User access control implementation
- Audit trail maintenance

### Network Security
- Use HTTPS in production
- Implement authentication
- Regular security updates
- Secure file upload handling

## Contributing

### Development Setup
1. Fork the repository
2. Create feature branch
3. Install development dependencies
4. Run tests before submitting
5. Follow code style guidelines

### Testing
```bash
# Run unit tests
python -m pytest tests/

# Run with coverage
python -m pytest tests/ --cov=src
```

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Changelog

### Version 1.0.0 (Current)
- Initial release with full inventory management features
- Excel integration and real-time dashboard
- Multi-channel sales tracking
- Comprehensive reporting and analytics
- Bulk upload and export capabilities

## Support

For support and questions:
1. Check this README and troubleshooting section
2. Review the logs for detailed error information
3. Ensure your setup matches the requirements
4. Verify data format compatibility

---

**Note**: This system is designed to work with your existing Excel-based inventory management workflow while providing a modern web interface and advanced analytics capabilities.