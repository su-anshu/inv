"""
Sidebar navigation component for the Inventory Management System
"""

import streamlit as st
from streamlit_option_menu import option_menu
import datetime
from src.utils.helpers import get_system_status

def create_sidebar():
    """Create and return the sidebar navigation"""
    
    with st.sidebar:
        # Logo and title
        st.image("static/images/logo.png", width=200) if st.file_uploader is not None else None
        st.title("📦 Inventory Manager")
        st.markdown("---")
        
        # Navigation menu
        selected = option_menu(
            menu_title="Navigation",
            options=[
                "📊 Dashboard",
                "📝 Data Entry", 
                "📈 Reports & Analytics",
                "💾 Download Center",
                "⚙️ Settings"
            ],
            icons=[
                "speedometer2",
                "pencil-square", 
                "graph-up",
                "download",
                "gear"
            ],
            menu_icon="list",
            default_index=0,
            styles={
                "container": {"padding": "5!important", "background-color": "#fafafa"},
                "icon": {"color": "orange", "font-size": "25px"}, 
                "nav-link": {
                    "font-size": "16px", 
                    "text-align": "left", 
                    "margin": "0px", 
                    "--hover-color": "#eee"
                },
                "nav-link-selected": {"background-color": "#FF4B4B"},
            }
        )
        
        st.markdown("---")
        
        # Quick Stats
        st.subheader("📋 Quick Stats")
        
        # Get current stats from session state or calculate
        if 'quick_stats' not in st.session_state:
            st.session_state.quick_stats = {
                'total_products': 0,
                'low_stock_items': 0,
                'pending_orders': 0,
                'today_sales': 0
            }
        
        stats = st.session_state.quick_stats
        
        # Display metrics
        col1, col2 = st.columns(2)
        with col1:
            st.metric(
                label="Products",
                value=stats['total_products'],
                delta=None
            )
            st.metric(
                label="Low Stock",
                value=stats['low_stock_items'],
                delta=None,
                delta_color="inverse"
            )
        
        with col2:
            st.metric(
                label="Pending",
                value=stats['pending_orders'],
                delta=None
            )
            st.metric(
                label="Today Sales",
                value=f"₹{stats['today_sales']:,.0f}",
                delta=None
            )
        
        st.markdown("---")
        
        # System Status
        st.subheader("🔧 System Status")
        status = get_system_status()
        
        if status['excel_connected']:
            st.success("✅ Excel Connected")
        else:
            st.error("❌ Excel Disconnected")
        
        if status['backup_status']:
            st.success("✅ Backup Active")
        else:
            st.warning("⚠️ Backup Inactive")
        
        # Last update time
        st.info(f"🕒 Last Update: {status['last_update']}")
        
        st.markdown("---")
        
        # Quick Actions
        st.subheader("⚡ Quick Actions")
        
        if st.button("🔄 Refresh Data", use_container_width=True):
            st.session_state.refresh_data = True
            st.experimental_rerun()
        
        if st.button("💾 Manual Backup", use_container_width=True):
            from src.services.backup_service import create_manual_backup
            if create_manual_backup():
                st.success("Backup created successfully!")
            else:
                st.error("Backup failed!")
        
        if st.button("📤 Quick Export", use_container_width=True):
            st.session_state.show_quick_export = True
        
        st.markdown("---")
        
        # Footer info
        st.caption(f"📅 {datetime.datetime.now().strftime('%Y-%m-%d')}")
        st.caption(f"🕐 {datetime.datetime.now().strftime('%H:%M:%S')}")
        
        # Alerts section
        if 'alerts' in st.session_state and st.session_state.alerts:
            st.markdown("---")
            st.subheader("🚨 Alerts")
            
            for alert in st.session_state.alerts[:3]:  # Show max 3 alerts
                if alert['type'] == 'error':
                    st.error(f"❌ {alert['message']}")
                elif alert['type'] == 'warning':
                    st.warning(f"⚠️ {alert['message']}")
                elif alert['type'] == 'info':
                    st.info(f"ℹ️ {alert['message']}")
            
            if len(st.session_state.alerts) > 3:
                st.caption(f"... and {len(st.session_state.alerts) - 3} more alerts")
        
        # Development info (only in dev mode)
        if st.session_state.get('dev_mode', False):
            st.markdown("---")
            st.subheader("🔧 Dev Info")
            st.caption(f"Session ID: {st.session_state.get('session_id', 'N/A')}")
            st.caption(f"Cache Size: {len(st.session_state)} items")
    
    return selected

def update_quick_stats(total_products=None, low_stock_items=None, 
                      pending_orders=None, today_sales=None):
    """Update the quick stats in the sidebar"""
    
    if 'quick_stats' not in st.session_state:
        st.session_state.quick_stats = {
            'total_products': 0,
            'low_stock_items': 0,
            'pending_orders': 0,
            'today_sales': 0
        }
    
    if total_products is not None:
        st.session_state.quick_stats['total_products'] = total_products
    if low_stock_items is not None:
        st.session_state.quick_stats['low_stock_items'] = low_stock_items
    if pending_orders is not None:
        st.session_state.quick_stats['pending_orders'] = pending_orders
    if today_sales is not None:
        st.session_state.quick_stats['today_sales'] = today_sales

def add_alert(message, alert_type='info'):
    """Add an alert to display in the sidebar"""
    
    if 'alerts' not in st.session_state:
        st.session_state.alerts = []
    
    alert = {
        'message': message,
        'type': alert_type,
        'timestamp': datetime.datetime.now()
    }
    
    st.session_state.alerts.insert(0, alert)
    
    # Keep only last 10 alerts
    if len(st.session_state.alerts) > 10:
        st.session_state.alerts = st.session_state.alerts[:10]