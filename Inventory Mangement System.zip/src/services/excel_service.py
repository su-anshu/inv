"""
Excel Service - Handles all Excel file operations
"""

import pandas as pd
import openpyxl
from openpyxl.styles import Font, Fill, PatternFill, Alignment
from openpyxl.utils.dataframe import dataframe_to_rows
import os
from datetime import datetime, date
from pathlib import Path
import shutil
import logging
from typing import Dict, List, Optional, Tuple, Any
import config

class ExcelService:
    """Service class for Excel file operations"""
    
    def __init__(self, excel_file_path: Optional[str] = None):
        """Initialize Excel service"""
        self.excel_file_path = excel_file_path or self._get_default_excel_path()
        self.logger = logging.getLogger(__name__)
        self._ensure_excel_file_exists()
    
    def _get_default_excel_path(self) -> str:
        """Get default Excel file path"""
        return str(config.UPLOADS_DIR / "stock_report.xlsx")
    
    def _ensure_excel_file_exists(self):
        """Ensure Excel file exists, create from template if not"""
        if not os.path.exists(self.excel_file_path):
            template_path = config.TEMPLATES_DIR / config.EXCEL_TEMPLATE_NAME
            if template_path.exists():
                shutil.copy(template_path, self.excel_file_path)
                self.logger.info(f"Created Excel file from template: {self.excel_file_path}")
            else:
                self._create_default_excel_file()
                self.logger.info(f"Created default Excel file: {self.excel_file_path}")
    
    def _create_default_excel_file(self):
        """Create a default Excel file with basic structure"""
        wb = openpyxl.Workbook()
        
        # Create sheets matching your structure
        sheet_names = list(config.SHEET_NAMES.values())
        
        # Remove default sheet and create new ones
        wb.remove(wb.active)
        
        for sheet_name in sheet_names:
            ws = wb.create_sheet(sheet_name)
            self._setup_sheet_structure(ws, sheet_name)
        
        wb.save(self.excel_file_path)
    
    def _setup_sheet_structure(self, worksheet, sheet_name: str):
        """Setup basic structure for each sheet"""
        if sheet_name == config.SHEET_NAMES["STOCK"]:
            headers = [
                "Row Labels", "Sum of Sum of Units Ordered", "Total Weight", 
                "% contribution", "Total Kgs to pack", "No of packets", 
                "Total Weight", "Pouch size", "FNSKU", "",
                "Physical Stock Count as on 06.06.2025 (Opening Stock of the day)",
                "Purchases", "Packaging", "", "Sales", "", "", "",
                "Returns", "", "", "", "Closing stock of the day(Formula)", 
                "Close of the Day Actual"
            ]
            
            for col, header in enumerate(headers, 1):
                cell = worksheet.cell(row=1, column=col, value=header)
                cell.font = Font(bold=True)
                cell.fill = PatternFill(start_color="DAE3F3", end_color="DAE3F3", fill_type="solid")
        
        elif sheet_name == config.SHEET_NAMES["RETURN"]:
            headers = ["Return", "Item Name", "Close"]
            for col, header in enumerate(headers, 1):
                worksheet.cell(row=1, column=col, value=header)
        
        # Add more sheet structures as needed
    
    def read_stock_data(self) -> pd.DataFrame:
        """Read stock data from Excel file"""
        try:
            df = pd.read_excel(
                self.excel_file_path, 
                sheet_name=config.SHEET_NAMES["STOCK"],
                header=0
            )
            return df
        except Exception as e:
            self.logger.error(f"Error reading stock data: {str(e)}")
            raise
    
    def read_all_data(self) -> Dict[str, pd.DataFrame]:
        """Read all sheets from Excel file"""
        try:
            all_data = {}
            for key, sheet_name in config.SHEET_NAMES.items():
                try:
                    df = pd.read_excel(self.excel_file_path, sheet_name=sheet_name, header=0)
                    all_data[key] = df
                except Exception as e:
                    self.logger.warning(f"Could not read sheet {sheet_name}: {str(e)}")
                    all_data[key] = pd.DataFrame()
            
            return all_data
        except Exception as e:
            self.logger.error(f"Error reading Excel file: {str(e)}")
            raise
    
    def update_opening_stock(self, entries: List[Dict]) -> bool:
        """Update opening stock in Excel file"""
        try:
            wb = openpyxl.load_workbook(self.excel_file_path)
            ws = wb[config.SHEET_NAMES["STOCK"]]
            
            # Find the correct row for each product and update
            for entry in entries:
                product_weight = entry['product']
                raw_stock = entry['raw_stock']
                finished_stock = entry['finished_stock']
                
                # Find the row for this product weight
                row_num = self._find_product_row(ws, product_weight)
                if row_num:
                    # Update opening stock column (assuming column K)
                    ws.cell(row=row_num, column=11, value=finished_stock)
                    self.logger.info(f"Updated opening stock for {product_weight}kg: {finished_stock}")
            
            # Update timestamp
            ws.cell(row=1, column=25, value=f"Last Updated: {datetime.now().strftime('%Y-%m-%d %H:%M')}")
            
            wb.save(self.excel_file_path)
            return True
            
        except Exception as e:
            self.logger.error(f"Error updating opening stock: {str(e)}")
            return False
    
    def record_sales(self, sales_entries: List[Dict], order_id: str, customer_info: str) -> bool:
        """Record sales transactions"""
        try:
            wb = openpyxl.load_workbook(self.excel_file_path)
            ws = wb[config.SHEET_NAMES["STOCK"]]
            
            for entry in sales_entries:
                product_weight = entry['product_weight']
                quantity = entry['quantity']
                channel = entry['channel']
                
                # Find product row
                row_num = self._find_product_row(ws, product_weight)
                if row_num:
                    # Update sales column based on channel
                    sales_col = self._get_sales_column(channel)
                    current_sales = ws.cell(row=row_num, column=sales_col).value or 0
                    ws.cell(row=row_num, column=sales_col, value=current_sales + quantity)
                    
                    # Update closing stock (recalculate)
                    self._recalculate_closing_stock(ws, row_num)
            
            # Log transaction
            self._log_transaction(wb, "SALES", sales_entries, order_id)
            
            wb.save(self.excel_file_path)
            return True
            
        except Exception as e:
            self.logger.error(f"Error recording sales: {str(e)}")
            return False
    
    def record_purchase(self, purchase_data: Dict) -> bool:
        """Record purchase transactions"""
        try:
            wb = openpyxl.load_workbook(self.excel_file_path)
            ws = wb[config.SHEET_NAMES["STOCK"]]
            
            # Update raw material stock
            raw_material_kg = purchase_data['raw_material_kg']
            
            # Find raw material row (usually row 10 in your structure)
            raw_material_row = self._find_raw_material_row(ws)
            if raw_material_row:
                # Update purchases column (column L)
                current_purchases = ws.cell(row=raw_material_row, column=12).value or 0
                ws.cell(row=raw_material_row, column=12, value=current_purchases + raw_material_kg)
            
            # Log transaction
            self._log_transaction(wb, "PURCHASE", purchase_data, purchase_data['invoice_number'])
            
            wb.save(self.excel_file_path)
            return True
            
        except Exception as e:
            self.logger.error(f"Error recording purchase: {str(e)}")
            return False
    
    def record_production(self, production_data: Dict) -> bool:
        """Record production/packaging operations"""
        try:
            wb = openpyxl.load_workbook(self.excel_file_path)
            ws = wb[config.SHEET_NAMES["STOCK"]]
            
            # Update raw material consumption
            raw_used = production_data['raw_material_used']
            raw_material_row = self._find_raw_material_row(ws)
            if raw_material_row:
                current_consumption = ws.cell(row=raw_material_row, column=13).value or 0
                ws.cell(row=raw_material_row, column=13, value=current_consumption + raw_used)
            
            # Update finished goods production
            for entry in production_data['production_entries']:
                product_weight = entry['weight']
                packets_produced = entry['packets']
                
                row_num = self._find_product_row(ws, product_weight)
                if row_num:
                    # Update packaging column (column M)
                    current_production = ws.cell(row=row_num, column=13).value or 0
                    ws.cell(row=row_num, column=13, value=current_production + packets_produced)
                    
                    # Recalculate closing stock
                    self._recalculate_closing_stock(ws, row_num)
            
            # Log transaction
            self._log_transaction(wb, "PRODUCTION", production_data, production_data['batch_number'])
            
            wb.save(self.excel_file_path)
            return True
            
        except Exception as e:
            self.logger.error(f"Error recording production: {str(e)}")
            return False
    
    def process_returns(self, return_data: Dict) -> bool:
        """Process returns"""
        try:
            wb = openpyxl.load_workbook(self.excel_file_path)
            ws = wb[config.SHEET_NAMES["STOCK"]]
            
            for entry in return_data['entries']:
                product_weight = entry['product_weight']
                quantity = entry['quantity']
                condition = entry['condition']
                channel = entry['channel']
                
                row_num = self._find_product_row(ws, product_weight)
                if row_num:
                    # Update returns column based on channel and condition
                    if condition == 'Good':
                        returns_col = self._get_returns_good_column(channel)
                    else:
                        returns_col = self._get_returns_bad_column(channel)
                    
                    current_returns = ws.cell(row=row_num, column=returns_col).value or 0
                    ws.cell(row=row_num, column=returns_col, value=current_returns + quantity)
                    
                    # Recalculate closing stock
                    self._recalculate_closing_stock(ws, row_num)
            
            # Log transaction
            self._log_transaction(wb, "RETURNS", return_data, return_data['return_id'])
            
            wb.save(self.excel_file_path)
            return True
            
        except Exception as e:
            self.logger.error(f"Error processing returns: {str(e)}")
            return False
    
    def apply_stock_adjustments(self, adjustment_data: Dict) -> bool:
        """Apply stock adjustments"""
        try:
            wb = openpyxl.load_workbook(self.excel_file_path)
            ws = wb[config.SHEET_NAMES["STOCK"]]
            
            for adjustment in adjustment_data['adjustments']:
                product_weight = adjustment['product_weight']
                new_stock = adjustment['physical_count']
                
                row_num = self._find_product_row(ws, product_weight)
                if row_num:
                    # Update actual closing stock (column X)
                    ws.cell(row=row_num, column=24, value=new_stock)
            
            # Log adjustment
            self._log_transaction(wb, "ADJUSTMENT", adjustment_data, adjustment_data['reference_number'])
            
            wb.save(self.excel_file_path)
            return True
            
        except Exception as e:
            self.logger.error(f"Error applying stock adjustments: {str(e)}")
            return False
    
    def get_available_stock(self) -> Dict[str, int]:
        """Get current available stock for all products"""
        try:
            df = self.read_stock_data()
            stock_dict = {}
            
            # Extract stock data from the dataframe
            # This depends on your exact Excel structure
            for index, row in df.iterrows():
                if pd.notna(row.get('Row Labels')) and 'kg' not in str(row.get('Row Labels')):
                    weight = str(row.get('Row Labels'))
                    if weight in ['0.2', '0.5', '1', '1.5', '2']:
                        stock = row.get('Close of the Day Actual', 0) or 0
                        stock_dict[f"{weight}kg"] = int(stock) if pd.notna(stock) else 0
            
            return stock_dict
            
        except Exception as e:
            self.logger.error(f"Error getting available stock: {str(e)}")
            return {}
    
    def check_stock_availability(self, sales_entries: List[Dict]) -> Dict[str, Any]:
        """Check if sufficient stock is available for sales"""
        try:
            available_stock = self.get_available_stock()
            
            for entry in sales_entries:
                product_key = f"{entry['product_weight']}kg"
                required_qty = entry['quantity']
                available_qty = available_stock.get(product_key, 0)
                
                if required_qty > available_qty:
                    return {
                        'available': False,
                        'message': f"Insufficient stock for {product_key}. Required: {required_qty}, Available: {available_qty}"
                    }
            
            return {'available': True, 'message': 'Sufficient stock available'}
            
        except Exception as e:
            self.logger.error(f"Error checking stock availability: {str(e)}")
            return {'available': False, 'message': f'Error checking stock: {str(e)}'}
    
    def get_current_stock(self, product: str) -> int:
        """Get current stock for a specific product"""
        try:
            available_stock = self.get_available_stock()
            return available_stock.get(product, 0)
        except:
            return 0
    
    def check_raw_material_availability(self, required_qty: float) -> bool:
        """Check if sufficient raw material is available"""
        try:
            df = self.read_stock_data()
            # Find raw material row and get current stock
            # This depends on your exact Excel structure
            return True  # Simplified for now
        except:
            return False
    
    def get_sales_data(self) -> Dict[str, Any]:
        """Get sales data for analytics"""
        try:
            # This would extract sales data from your Excel
            # For now, returning sample structure
            return {
                'today': [],
                'daily_sales': {},
                'channel_sales': {
                    'Amazon FBA': 45000,
                    'Amazon Easyship': 25000,
                    'Flipkart': 20000,
                    'Others': 10000
                },
                'avg_daily_sales': 10000
            }
        except Exception as e:
            self.logger.error(f"Error getting sales data: {str(e)}")
            return {}
    
    def check_excel_connection(self) -> bool:
        """Check if Excel file is accessible"""
        try:
            return os.path.exists(self.excel_file_path) and os.access(self.excel_file_path, os.R_OK | os.W_OK)
        except:
            return False
    
    def _find_product_row(self, worksheet, product_weight: str) -> Optional[int]:
        """Find the row number for a specific product weight"""
        for row in range(2, worksheet.max_row + 1):
            cell_value = worksheet.cell(row=row, column=1).value
            if str(cell_value) == str(product_weight):
                return row
        return None
    
    def _find_raw_material_row(self, worksheet) -> Optional[int]:
        """Find the raw material row"""
        for row in range(2, worksheet.max_row + 1):
            cell_value = worksheet.cell(row=row, column=1).value
            if cell_value and "In lot" in str(cell_value):
                return row
        return None
    
    def _get_sales_column(self, channel: str) -> int:
        """Get the column number for sales based on channel"""
        channel_columns = {
            "Amazon FBA": 16,        # Column P
            "Amazon Easyship": 15,   # Column O
            "Flipkart": 17,          # Column Q
            "Others": 18             # Column R
        }
        return channel_columns.get(channel, 15)
    
    def _get_returns_good_column(self, channel: str) -> int:
        """Get the column number for good returns based on channel"""
        channel_columns = {
            "Amazon FBA": 20,        # Column T
            "Amazon Easyship": 19,   # Column S
            "Flipkart": 21,          # Column U
            "Others": 22             # Column V
        }
        return channel_columns.get(channel, 19)
    
    def _get_returns_bad_column(self, channel: str) -> int:
        """Get the column number for bad returns based on channel"""
        # Assuming bad stock columns are next to good stock columns
        return self._get_returns_good_column(channel) + 1
    
    def _recalculate_closing_stock(self, worksheet, row_num: int):
        """Recalculate closing stock for a product row"""
        try:
            # Get opening stock
            opening_stock = worksheet.cell(row=row_num, column=11).value or 0
            
            # Get purchases/inwards
            purchases = worksheet.cell(row=row_num, column=12).value or 0
            
            # Get packaging/production
            packaging = worksheet.cell(row=row_num, column=13).value or 0
            
            # Get total sales (sum of all sales channels)
            total_sales = 0
            for col in range(15, 19):  # Columns O to R
                sales = worksheet.cell(row=row_num, column=col).value or 0
                total_sales += sales
            
            # Get total returns (sum of good returns only for stock calculation)
            total_good_returns = 0
            for col in range(19, 23, 2):  # Good returns columns
                returns = worksheet.cell(row=row_num, column=col).value or 0
                total_good_returns += returns
            
            # Calculate closing stock: Opening + Purchases + Packaging + Good Returns - Sales
            closing_stock = opening_stock + purchases + packaging + total_good_returns - total_sales
            
            # Update formula-calculated closing stock (column W)
            worksheet.cell(row=row_num, column=23, value=max(0, closing_stock))
            
        except Exception as e:
            self.logger.error(f"Error recalculating closing stock: {str(e)}")
    
    def _log_transaction(self, workbook, transaction_type: str, data: Dict, reference: str):
        """Log transaction to a transactions sheet or log file"""
        try:
            # Check if transactions sheet exists, create if not
            if "Transactions" not in workbook.sheetnames:
                ws = workbook.create_sheet("Transactions")
                headers = ["Timestamp", "Type", "Reference", "Details", "User"]
                for col, header in enumerate(headers, 1):
                    ws.cell(row=1, column=col, value=header)
            else:
                ws = workbook["Transactions"]
            
            # Add new transaction row
            new_row = ws.max_row + 1
            ws.cell(row=new_row, column=1, value=datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
            ws.cell(row=new_row, column=2, value=transaction_type)
            ws.cell(row=new_row, column=3, value=reference)
            ws.cell(row=new_row, column=4, value=str(data)[:100])  # Truncate for readability
            ws.cell(row=new_row, column=5, value="System User")
            
        except Exception as e:
            self.logger.error(f"Error logging transaction: {str(e)}")
    
    def export_data(self, export_format: str = "xlsx", include_charts: bool = False) -> str:
        """Export data in specified format"""
        try:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            
            if export_format.lower() == "xlsx":
                export_path = config.EXPORTS_DIR / f"stock_report_export_{timestamp}.xlsx"
                shutil.copy(self.excel_file_path, export_path)
                
            elif export_format.lower() == "csv":
                export_path = config.EXPORTS_DIR / f"stock_report_export_{timestamp}.csv"
                df = self.read_stock_data()
                df.to_csv(export_path, index=False)
                
            elif export_format.lower() == "pdf":
                # PDF export would require additional libraries like reportlab
                export_path = config.EXPORTS_DIR / f"stock_report_export_{timestamp}.pdf"
                self._export_to_pdf(export_path)
            
            return str(export_path)
            
        except Exception as e:
            self.logger.error(f"Error exporting data: {str(e)}")
            raise
    
    def _export_to_pdf(self, export_path: str):
        """Export data to PDF format"""
        try:
            from reportlab.lib.pagesizes import letter, A4
            from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
            from reportlab.lib.styles import getSampleStyleSheet
            from reportlab.lib import colors
            
            # Create PDF document
            doc = SimpleDocTemplate(export_path, pagesize=A4)
            elements = []
            styles = getSampleStyleSheet()
            
            # Title
            title = Paragraph("Stock Report", styles['Title'])
            elements.append(title)
            elements.append(Spacer(1, 12))
            
            # Date
            date_para = Paragraph(f"Generated on: {datetime.now().strftime('%Y-%m-%d %H:%M')}", styles['Normal'])
            elements.append(date_para)
            elements.append(Spacer(1, 12))
            
            # Stock data table
            df = self.read_stock_data()
            if not df.empty:
                # Prepare table data
                table_data = [df.columns.tolist()]
                for _, row in df.head(20).iterrows():  # Limit to first 20 rows
                    table_data.append(row.tolist())
                
                # Create table
                table = Table(table_data)
                table.setStyle(TableStyle([
                    ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
                    ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
                    ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                    ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                    ('FONTSIZE', (0, 0), (-1, 0), 10),
                    ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
                    ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
                    ('GRID', (0, 0), (-1, -1), 1, colors.black)
                ]))
                
                elements.append(table)
            
            doc.build(elements)
            
        except ImportError:
            # If reportlab is not available, create a simple text file
            with open(export_path.replace('.pdf', '.txt'), 'w') as f:
                f.write("Stock Report\n")
                f.write("=" * 50 + "\n")
                f.write(f"Generated on: {datetime.now().strftime('%Y-%m-%d %H:%M')}\n\n")
                
                df = self.read_stock_data()
                f.write(df.to_string())
            
            return export_path.replace('.pdf', '.txt')
        except Exception as e:
            self.logger.error(f"Error creating PDF: {str(e)}")
            raise
    
    def backup_excel_file(self) -> str:
        """Create a backup of the current Excel file"""
        try:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            backup_filename = f"{config.EXCEL_BACKUP_PREFIX}stock_report_{timestamp}.xlsx"
            backup_path = config.EXPORTS_DIR / backup_filename
            
            shutil.copy(self.excel_file_path, backup_path)
            
            # Clean up old backups
            self._cleanup_old_backups()
            
            return str(backup_path)
            
        except Exception as e:
            self.logger.error(f"Error creating backup: {str(e)}")
            raise
    
    def _cleanup_old_backups(self):
        """Remove old backup files to save space"""
        try:
            backup_files = []
            for file in config.EXPORTS_DIR.glob(f"{config.EXCEL_BACKUP_PREFIX}*.xlsx"):
                backup_files.append((file, file.stat().st_mtime))
            
            # Sort by modification time (newest first)
            backup_files.sort(key=lambda x: x[1], reverse=True)
            
            # Keep only the latest MAX_BACKUP_FILES
            if len(backup_files) > config.MAX_BACKUP_FILES:
                for file_path, _ in backup_files[config.MAX_BACKUP_FILES:]:
                    file_path.unlink()
                    self.logger.info(f"Deleted old backup: {file_path}")
                    
        except Exception as e:
            self.logger.error(f"Error cleaning up backups: {str(e)}")
    
    def restore_from_backup(self, backup_path: str) -> bool:
        """Restore Excel file from backup"""
        try:
            if not os.path.exists(backup_path):
                raise FileNotFoundError(f"Backup file not found: {backup_path}")
            
            # Create backup of current file before restore
            current_backup = self.backup_excel_file()
            self.logger.info(f"Created backup of current file: {current_backup}")
            
            # Restore from backup
            shutil.copy(backup_path, self.excel_file_path)
            self.logger.info(f"Restored from backup: {backup_path}")
            
            return True
            
        except Exception as e:
            self.logger.error(f"Error restoring from backup: {str(e)}")
            return False
    
    def validate_excel_file(self) -> Dict[str, Any]:
        """Validate the Excel file structure and data"""
        try:
            validation_results = {
                'valid': True,
                'errors': [],
                'warnings': [],
                'sheet_status': {}
            }
            
            # Check if file exists
            if not os.path.exists(self.excel_file_path):
                validation_results['valid'] = False
                validation_results['errors'].append("Excel file not found")
                return validation_results
            
            # Check each sheet
            for key, sheet_name in config.SHEET_NAMES.items():
                try:
                    df = pd.read_excel(self.excel_file_path, sheet_name=sheet_name)
                    validation_results['sheet_status'][sheet_name] = {
                        'exists': True,
                        'rows': len(df),
                        'columns': len(df.columns)
                    }
                except Exception as e:
                    validation_results['valid'] = False
                    validation_results['errors'].append(f"Cannot read sheet '{sheet_name}': {str(e)}")
                    validation_results['sheet_status'][sheet_name] = {
                        'exists': False,
                        'error': str(e)
                    }
            
            # Additional data validation
            try:
                stock_data = self.read_stock_data()
                
                # Check for negative stock values
                if 'Close of the Day Actual' in stock_data.columns:
                    negative_stock = stock_data[stock_data['Close of the Day Actual'] < 0]
                    if not negative_stock.empty:
                        validation_results['warnings'].append(f"Found {len(negative_stock)} items with negative stock")
                
                # Check for missing critical data
                if stock_data.empty:
                    validation_results['warnings'].append("Stock sheet appears to be empty")
                    
            except Exception as e:
                validation_results['warnings'].append(f"Could not validate stock data: {str(e)}")
            
            return validation_results
            
        except Exception as e:
            self.logger.error(f"Error validating Excel file: {str(e)}")
            return {
                'valid': False,
                'errors': [f"Validation failed: {str(e)}"],
                'warnings': [],
                'sheet_status': {}
            }
    
    def bulk_update_from_dataframe(self, df: pd.DataFrame, sheet_name: str) -> bool:
        """Update Excel sheet with data from DataFrame"""
        try:
            wb = openpyxl.load_workbook(self.excel_file_path)
            
            if sheet_name in wb.sheetnames:
                # Remove existing sheet
                wb.remove(wb[sheet_name])
            
            # Create new sheet
            ws = wb.create_sheet(sheet_name)
            
            # Write DataFrame to sheet
            for r in dataframe_to_rows(df, index=False, header=True):
                ws.append(r)
            
            # Apply basic formatting
            for cell in ws[1]:  # Header row
                cell.font = Font(bold=True)
                cell.fill = PatternFill(start_color="DAE3F3", end_color="DAE3F3", fill_type="solid")
            
            wb.save(self.excel_file_path)
            return True
            
        except Exception as e:
            self.logger.error(f"Error bulk updating from DataFrame: {str(e)}")
            return False
    
    def get_file_info(self) -> Dict[str, Any]:
        """Get information about the Excel file"""
        try:
            file_path = Path(self.excel_file_path)
            file_stats = file_path.stat()
            
            return {
                'file_path': str(file_path),
                'file_size': file_stats.st_size,
                'file_size_mb': round(file_stats.st_size / 1024 / 1024, 2),
                'created': datetime.fromtimestamp(file_stats.st_ctime),
                'modified': datetime.fromtimestamp(file_stats.st_mtime),
                'accessible': os.access(self.excel_file_path, os.R_OK | os.W_OK),
                'sheets': list(config.SHEET_NAMES.values())
            }
            
        except Exception as e:
            self.logger.error(f"Error getting file info: {str(e)}")
            return {}