"""
Data Validation Service - Validates all data entry operations
"""

import re
from typing import Dict, List, Any, Tuple, Optional
from datetime import datetime, date
import pandas as pd
import config

class DataValidator:
    """Service class for data validation"""
    
    def __init__(self):
        self.validation_rules = config.VALIDATION_RULES
        self.required_fields = self.validation_rules.get("REQUIRED_FIELDS", [])
        self.min_stock = self.validation_rules.get("MIN_STOCK", 0)
        self.max_stock = self.validation_rules.get("MAX_STOCK", 10000)
        self.min_weight = self.validation_rules.get("MIN_WEIGHT", 0.1)
        self.max_weight = self.validation_rules.get("MAX_WEIGHT", 5.0)
    
    def validate_stock_entry(self, entry: Dict[str, Any]) -> bool:
        """Validate stock entry data"""
        try:
            # Check required fields
            if not self._check_required_fields(entry, ['product', 'date']):
                return False
            
            # Validate stock quantities
            raw_stock = entry.get('raw_stock', 0)
            finished_stock = entry.get('finished_stock', 0)
            
            if not self._validate_quantity(raw_stock) or not self._validate_quantity(finished_stock):
                return False
            
            # Validate product weight
            product_weight = entry.get('product')
            if not self._validate_product_weight(product_weight):
                return False
            
            # Validate date
            if not self._validate_date(entry.get('date')):
                return False
            
            return True
            
        except Exception as e:
            print(f"Stock entry validation error: {str(e)}")
            return False
    
    def validate_sales_entry(self, entry: Dict[str, Any]) -> bool:
        """Validate sales entry data"""
        try:
            # Check required fields
            required_fields = ['product_weight', 'quantity', 'price', 'channel', 'date']
            if not self._check_required_fields(entry, required_fields):
                return False
            
            # Validate quantity
            quantity = entry.get('quantity', 0)
            if not self._validate_quantity(quantity) or quantity <= 0:
                return False
            
            # Validate price
            price = entry.get('price', 0)
            if not isinstance(price, (int, float)) or price < 0:
                return False
            
            # Validate product weight
            if not self._validate_product_weight(entry.get('product_weight')):
                return False
            
            # Validate channel
            if not self._validate_sales_channel(entry.get('channel')):
                return False
            
            # Validate date
            if not self._validate_date(entry.get('date')):
                return False
            
            return True
            
        except Exception as e:
            print(f"Sales entry validation error: {str(e)}")
            return False
    
    def validate_purchase_entry(self, entry: Dict[str, Any]) -> bool:
        """Validate purchase entry data"""
        try:
            # Check required fields
            required_fields = ['supplier', 'date', 'raw_material_kg']
            if not self._check_required_fields(entry, required_fields):
                return False
            
            # Validate supplier name
            supplier = entry.get('supplier', '').strip()
            if not supplier or len(supplier) < 2:
                return False
            
            # Validate raw material quantity
            raw_material_kg = entry.get('raw_material_kg', 0)
            if not isinstance(raw_material_kg, (int, float)) or raw_material_kg < 0:
                return False
            
            # Validate total amount
            total_amount = entry.get('total_amount', 0)
            if not isinstance(total_amount, (int, float)) or total_amount < 0:
                return False
            
            # Validate rate consistency
            raw_material_rate = entry.get('raw_material_rate', 0)
            if raw_material_kg > 0 and raw_material_rate > 0:
                calculated_amount = raw_material_kg * raw_material_rate
                if abs(calculated_amount - total_amount) > total_amount * 0.1:  # 10% tolerance
                    print("Warning: Rate calculation doesn't match total amount")
            
            # Validate date
            if not self._validate_date(entry.get('date')):
                return False
            
            # Validate packaging items if present
            packaging_items = entry.get('packaging_items', [])
            for item in packaging_items:
                if not self._validate_packaging_item(item):
                    return False
            
            return True
            
        except Exception as e:
            print(f"Purchase entry validation error: {str(e)}")
            return False
    
    def validate_production_entry(self, entry: Dict[str, Any]) -> bool:
        """Validate production/packaging entry data"""
        try:
            # Check required fields
            required_fields = ['date', 'raw_material_used', 'production_entries']
            if not self._check_required_fields(entry, required_fields):
                return False
            
            # Validate raw material used
            raw_material_used = entry.get('raw_material_used', 0)
            if not isinstance(raw_material_used, (int, float)) or raw_material_used < 0:
                return False
            
            # Validate production entries
            production_entries = entry.get('production_entries', [])
            if not production_entries:
                return False
            
            total_output_weight = 0
            for prod_entry in production_entries:
                if not self._validate_production_item(prod_entry):
                    return False
                total_output_weight += prod_entry.get('total_weight', 0)
            
            # Check material balance (output shouldn't exceed input by too much)
            # Allow for some processing loss
            if total_output_weight > raw_material_used * 1.05:  # 5% tolerance for processing
                print("Warning: Output weight exceeds input material")
            
            # Validate operator name
            operator = entry.get('operator', '').strip()
            if operator and len(operator) < 2:
                return False
            
            # Validate batch number format
            batch_number = entry.get('batch_number', '').strip()
            if batch_number and not self._validate_batch_number(batch_number):
                return False
            
            # Validate date
            if not self._validate_date(entry.get('date')):
                return False
            
            return True
            
        except Exception as e:
            print(f"Production entry validation error: {str(e)}")
            return False
    
    def validate_return_entry(self, entry: Dict[str, Any]) -> bool:
        """Validate return entry data"""
        try:
            # Check required fields
            required_fields = ['channel', 'date', 'entries']
            if not self._check_required_fields(entry, required_fields):
                return False
            
            # Validate channel
            if not self._validate_sales_channel(entry.get('channel')):
                return False
            
            # Validate return entries
            return_entries = entry.get('entries', [])
            if not return_entries:
                return False
            
            for return_item in return_entries:
                if not self._validate_return_item(return_item):
                    return False
            
            # Validate return reason
            reason = entry.get('reason', '')
            if not self._validate_return_reason(reason):
                return False
            
            # Validate date
            if not self._validate_date(entry.get('date')):
                return False
            
            return True
            
        except Exception as e:
            print(f"Return entry validation error: {str(e)}")
            return False
    
    def validate_stock_adjustment(self, entry: Dict[str, Any]) -> bool:
        """Validate stock adjustment entry"""
        try:
            # Check required fields
            required_fields = ['date', 'reason', 'adjustments']
            if not self._check_required_fields(entry, required_fields):
                return False
            
            # Validate adjustments
            adjustments = entry.get('adjustments', [])
            if not adjustments:
                return False
            
            for adjustment in adjustments:
                if not self._validate_adjustment_item(adjustment):
                    return False
            
            # Validate reason
            reason = entry.get('reason', '')
            if not self._validate_adjustment_reason(reason):
                return False
            
            # Validate authorized person
            authorized_by = entry.get('authorized_by', '').strip()
            if not authorized_by or len(authorized_by) < 2:
                return False
            
            # Validate date
            if not self._validate_date(entry.get('date')):
                return False
            
            return True
            
        except Exception as e:
            print(f"Stock adjustment validation error: {str(e)}")
            return False
    
    def validate_bulk_upload_data(self, df: pd.DataFrame, upload_type: str) -> Dict[str, Any]:
        """Validate bulk upload data"""
        try:
            validation_result = {
                'valid': True,
                'errors': [],
                'warnings': [],
                'valid_rows': 0,
                'invalid_rows': 0,
                'processed_data': []
            }
            
            if df.empty:
                validation_result['valid'] = False
                validation_result['errors'].append("No data found in uploaded file")
                return validation_result
            
            # Validate based on upload type
            if upload_type == "sales":
                return self._validate_bulk_sales_data(df, validation_result)
            elif upload_type == "purchases":
                return self._validate_bulk_purchase_data(df, validation_result)
            elif upload_type == "stock":
                return self._validate_bulk_stock_data(df, validation_result)
            else:
                validation_result['valid'] = False
                validation_result['errors'].append(f"Unknown upload type: {upload_type}")
                return validation_result
            
        except Exception as e:
            return {
                'valid': False,
                'errors': [f"Bulk validation error: {str(e)}"],
                'warnings': [],
                'valid_rows': 0,
                'invalid_rows': 0,
                'processed_data': []
            }
    
    def _check_required_fields(self, entry: Dict[str, Any], required_fields: List[str]) -> bool:
        """Check if all required fields are present and not empty"""
        for field in required_fields:
            value = entry.get(field)
            if value is None or (isinstance(value, str) and not value.strip()):
                print(f"Missing required field: {field}")
                return False
        return True
    
    def _validate_quantity(self, quantity: Any) -> bool:
        """Validate quantity values"""
        if not isinstance(quantity, (int, float)):
            return False
        return self.min_stock <= quantity <= self.max_stock
    
    def _validate_product_weight(self, weight: Any) -> bool:
        """Validate product weight"""
        if not weight:
            return False
        
        try:
            weight_str = str(weight).strip()
            # Check if it's one of the valid weights
            valid_weights = ["0.2", "0.5", "1", "1.0", "1.5", "2", "2.0"]
            return weight_str in valid_weights
        except:
            return False
    
    def _validate_sales_channel(self, channel: str) -> bool:
        """Validate sales channel"""
        if not channel:
            return False
        
        valid_channels = [
            "Amazon FBA", "Amazon Easyship", "Flipkart", "Others"
        ]
        return channel in valid_channels
    
    def _validate_date(self, date_value: Any) -> bool:
        """Validate date values"""
        if not date_value:
            return False
        
        try:
            if isinstance(date_value, (date, datetime)):
                # Check if date is not in the future
                return date_value.date() <= datetime.now().date()
            
            # If it's a string, try to parse it
            if isinstance(date_value, str):
                parsed_date = datetime.strptime(date_value, "%Y-%m-%d").date()
                return parsed_date <= datetime.now().date()
            
            return False
        except:
            return False
    
    def _validate_packaging_item(self, item: Dict[str, Any]) -> bool:
        """Validate packaging item data"""
        try:
            name = item.get('name', '').strip()
            quantity = item.get('quantity', 0)
            rate = item.get('rate', 0)
            
            if not name or len(name) < 2:
                return False
            
            if not isinstance(quantity, (int, float)) or quantity <= 0:
                return False
            
            if not isinstance(rate, (int, float)) or rate < 0:
                return False
            
            return True
        except:
            return False
    
    def _validate_production_item(self, item: Dict[str, Any]) -> bool:
        """Validate production item data"""
        try:
            weight = item.get('weight')
            packets = item.get('packets', 0)
            total_weight = item.get('total_weight', 0)
            
            if not self._validate_product_weight(weight):
                return False
            
            if not isinstance(packets, int) or packets <= 0:
                return False
            
            # Check weight calculation
            expected_weight = packets * float(weight)
            if abs(expected_weight - total_weight) > 0.01:  # Small tolerance for floating point
                return False
            
            return True
        except:
            return False
    
    def _validate_return_item(self, item: Dict[str, Any]) -> bool:
        """Validate return item data"""
        try:
            product_weight = item.get('product_weight')
            quantity = item.get('quantity', 0)
            condition = item.get('condition', '')
            action = item.get('action', '')
            
            if not self._validate_product_weight(product_weight):
                return False
            
            if not isinstance(quantity, int) or quantity <= 0:
                return False
            
            valid_conditions = ["Good", "Damaged", "Expired"]
            if condition not in valid_conditions:
                return False
            
            valid_actions = ["Restock", "Discard", "Repair", "Hold"]
            if action not in valid_actions:
                return False
            
            return True
        except:
            return False
    
    def _validate_return_reason(self, reason: str) -> bool:
        """Validate return reason"""
        valid_reasons = [
            "Customer Return", "Damaged in Transit", "Quality Issue",
            "Wrong Product", "Expired Product", "Other"
        ]
        return reason in valid_reasons
    
    def _validate_adjustment_item(self, item: Dict[str, Any]) -> bool:
        """Validate stock adjustment item"""
        try:
            product_weight = item.get('product_weight')
            current_stock = item.get('current_stock', 0)
            physical_count = item.get('physical_count', 0)
            adjustment = item.get('adjustment', 0)
            
            if not self._validate_product_weight(product_weight):
                return False
            
            if not isinstance(current_stock, (int, float)) or current_stock < 0:
                return False
            
            if not isinstance(physical_count, (int, float)) or physical_count < 0:
                return False
            
            # Check adjustment calculation
            expected_adjustment = physical_count - current_stock
            if abs(expected_adjustment - adjustment) > 0.01:
                return False
            
            return True
        except:
            return False
    
    def _validate_adjustment_reason(self, reason: str) -> bool:
        """Validate stock adjustment reason"""
        valid_reasons = [
            "Physical Count Difference", "Damage/Wastage", "System Error Correction",
            "Theft/Loss", "Quality Rejection", "Other"
        ]
        return reason in valid_reasons
    
    def _validate_batch_number(self, batch_number: str) -> bool:
        """Validate batch number format"""
        if not batch_number:
            return True  # Optional field
        
        # Basic format validation - adjust pattern as needed
        pattern = r'^[A-Z0-9\-_]{3,20}
        return bool(re.match(pattern, batch_number.upper()))
    
    def _validate_bulk_sales_data(self, df: pd.DataFrame, validation_result: Dict) -> Dict:
        """Validate bulk sales data"""
        required_columns = ['date', 'product_weight', 'quantity', 'price', 'channel']
        
        # Check required columns
        missing_columns = [col for col in required_columns if col not in df.columns]
        if missing_columns:
            validation_result['valid'] = False
            validation_result['errors'].append(f"Missing required columns: {missing_columns}")
            return validation_result
        
        # Validate each row
        for index, row in df.iterrows():
            row_errors = []
            
            # Validate date
            try:
                date_val = pd.to_datetime(row['date']).date()
                if date_val > datetime.now().date():
                    row_errors.append("Date cannot be in the future")
            except:
                row_errors.append("Invalid date format")
            
            # Validate product weight
            if not self._validate_product_weight(row['product_weight']):
                row_errors.append("Invalid product weight")
            
            # Validate quantity
            try:
                qty = float(row['quantity'])
                if qty <= 0 or qty > self.max_stock:
                    row_errors.append("Invalid quantity")
            except:
                row_errors.append("Quantity must be a number")
            
            # Validate price
            try:
                price = float(row['price'])
                if price < 0:
                    row_errors.append("Price cannot be negative")
            except:
                row_errors.append("Price must be a number")
            
            # Validate channel
            if not self._validate_sales_channel(row['channel']):
                row_errors.append("Invalid sales channel")
            
            if row_errors:
                validation_result['invalid_rows'] += 1
                validation_result['errors'].extend([f"Row {index + 2}: {error}" for error in row_errors])
            else:
                validation_result['valid_rows'] += 1
                validation_result['processed_data'].append(row.to_dict())
        
        if validation_result['invalid_rows'] > 0:
            validation_result['valid'] = False
        
        return validation_result
    
    def _validate_bulk_purchase_data(self, df: pd.DataFrame, validation_result: Dict) -> Dict:
        """Validate bulk purchase data"""
        required_columns = ['date', 'supplier', 'raw_material_kg', 'rate_per_kg', 'total_amount']
        
        # Check required columns
        missing_columns = [col for col in required_columns if col not in df.columns]
        if missing_columns:
            validation_result['valid'] = False
            validation_result['errors'].append(f"Missing required columns: {missing_columns}")
            return validation_result
        
        # Validate each row
        for index, row in df.iterrows():
            row_errors = []
            
            # Validate date
            try:
                date_val = pd.to_datetime(row['date']).date()
                if date_val > datetime.now().date():
                    row_errors.append("Date cannot be in the future")
            except:
                row_errors.append("Invalid date format")
            
            # Validate supplier
            if not row['supplier'] or len(str(row['supplier']).strip()) < 2:
                row_errors.append("Invalid supplier name")
            
            # Validate quantities and amounts
            try:
                raw_kg = float(row['raw_material_kg'])
                rate = float(row['rate_per_kg'])
                total = float(row['total_amount'])
                
                if raw_kg <= 0:
                    row_errors.append("Raw material quantity must be positive")
                if rate <= 0:
                    row_errors.append("Rate must be positive")
                if total <= 0:
                    row_errors.append("Total amount must be positive")
                
                # Check calculation consistency
                expected_total = raw_kg * rate
                if abs(expected_total - total) > total * 0.1:  # 10% tolerance
                    row_errors.append("Amount calculation inconsistent")
                    
            except:
                row_errors.append("Invalid numeric values")
            
            if row_errors:
                validation_result['invalid_rows'] += 1
                validation_result['errors'].extend([f"Row {index + 2}: {error}" for error in row_errors])
            else:
                validation_result['valid_rows'] += 1
                validation_result['processed_data'].append(row.to_dict())
        
        if validation_result['invalid_rows'] > 0:
            validation_result['valid'] = False
        
        return validation_result
    
    def _validate_bulk_stock_data(self, df: pd.DataFrame, validation_result: Dict) -> Dict:
        """Validate bulk stock data"""
        required_columns = ['product_weight', 'opening_stock', 'date']
        
        # Check required columns
        missing_columns = [col for col in required_columns if col not in df.columns]
        if missing_columns:
            validation_result['valid'] = False
            validation_result['errors'].append(f"Missing required columns: {missing_columns}")
            return validation_result
        
        # Validate each row
        for index, row in df.iterrows():
            row_errors = []
            
            # Validate product weight
            if not self._validate_product_weight(row['product_weight']):
                row_errors.append("Invalid product weight")
            
            # Validate stock quantity
            try:
                stock = float(row['opening_stock'])
                if stock < 0 or stock > self.max_stock:
                    row_errors.append("Invalid stock quantity")
            except:
                row_errors.append("Stock must be a number")
            
            # Validate date
            try:
                date_val = pd.to_datetime(row['date']).date()
                if date_val > datetime.now().date():
                    row_errors.append("Date cannot be in the future")
            except:
                row_errors.append("Invalid date format")
            
            if row_errors:
                validation_result['invalid_rows'] += 1
                validation_result['errors'].extend([f"Row {index + 2}: {error}" for error in row_errors])
            else:
                validation_result['valid_rows'] += 1
                validation_result['processed_data'].append(row.to_dict())
        
        if validation_result['invalid_rows'] > 0:
            validation_result['valid'] = False
        
        return validation_result
    
    def validate_file_format(self, file_path: str, expected_format: str) -> bool:
        """Validate uploaded file format"""
        try:
            file_extension = file_path.split('.')[-1].lower()
            
            valid_formats = {
                'excel': ['xlsx', 'xls'],
                'csv': ['csv'],
                'pdf': ['pdf']
            }
            
            return file_extension in valid_formats.get(expected_format, [])
            
        except:
            return False
    
    def validate_file_size(self, file_size: int, max_size_mb: int = 50) -> bool:
        """Validate file size"""
        max_size_bytes = max_size_mb * 1024 * 1024
        return file_size <= max_size_bytes
    
    def sanitize_input(self, input_value: Any, input_type: str = "text") -> Any:
        """Sanitize user input"""
        try:
            if input_value is None:
                return None
            
            if input_type == "text":
                # Remove harmful characters and trim
                cleaned = str(input_value).strip()
                # Remove potentially dangerous characters
                cleaned = re.sub(r'[<>"\']', '', cleaned)
                return cleaned
            
            elif input_type == "number":
                if isinstance(input_value, (int, float)):
                    return input_value
                try:
                    return float(str(input_value).replace(',', ''))
                except:
                    return 0
            
            elif input_type == "integer":
                if isinstance(input_value, int):
                    return input_value
                try:
                    return int(float(str(input_value).replace(',', '')))
                except:
                    return 0
            
            elif input_type == "email":
                email_pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}
                cleaned = str(input_value).strip().lower()
                if re.match(email_pattern, cleaned):
                    return cleaned
                return None
            
            elif input_type == "phone":
                # Remove non-digit characters except +
                cleaned = re.sub(r'[^\d+]', '', str(input_value))
                return cleaned if len(cleaned) >= 10 else None
            
            else:
                return str(input_value).strip()
                
        except:
            return None
    
    def get_validation_summary(self, validation_results: List[Dict]) -> Dict[str, Any]:
        """Get summary of validation results"""
        try:
            total_entries = len(validation_results)
            valid_entries = sum(1 for result in validation_results if result.get('valid', False))
            invalid_entries = total_entries - valid_entries
            
            all_errors = []
            all_warnings = []
            
            for result in validation_results:
                all_errors.extend(result.get('errors', []))
                all_warnings.extend(result.get('warnings', []))
            
            return {
                'total_entries': total_entries,
                'valid_entries': valid_entries,
                'invalid_entries': invalid_entries,
                'success_rate': (valid_entries / total_entries * 100) if total_entries > 0 else 0,
                'total_errors': len(all_errors),
                'total_warnings': len(all_warnings),
                'common_errors': self._get_common_issues(all_errors),
                'common_warnings': self._get_common_issues(all_warnings)
            }
            
        except Exception as e:
            return {
                'error': f"Failed to generate validation summary: {str(e)}"
            }
    
    def _get_common_issues(self, issues: List[str]) -> List[Dict[str, Any]]:
        """Get most common validation issues"""
        try:
            from collections import Counter
            
            # Count occurrences of each error type
            issue_counts = Counter(issues)
            
            # Return top 5 most common issues
            common_issues = []
            for issue, count in issue_counts.most_common(5):
                common_issues.append({
                    'issue': issue,
                    'count': count,
                    'percentage': (count / len(issues) * 100) if issues else 0
                })
            
            return common_issues
            
        except:
            return []
    
    def validate_business_rules(self, entry: Dict[str, Any], operation_type: str) -> Dict[str, Any]:
        """Validate business-specific rules"""
        try:
            business_validation = {
                'valid': True,
                'warnings': [],
                'suggestions': []
            }
            
            if operation_type == "sales":
                # Check if selling during peak hours
                if 'date' in entry:
                    hour = datetime.now().hour
                    if hour < 9 or hour > 18:
                        business_validation['warnings'].append("Sale recorded outside business hours")
                
                # Check for unusually large orders
                quantity = entry.get('quantity', 0)
                if quantity > 100:
                    business_validation['warnings'].append("Large order quantity - verify accuracy")
                
                # Suggest optimal pricing
                price = entry.get('price', 0)
                weight = entry.get('product_weight', '')
                expected_price = self._get_expected_price(weight)
                if expected_price and abs(price - expected_price) / expected_price > 0.2:
                    business_validation['suggestions'].append(f"Price variance detected. Expected: ₹{expected_price}")
            
            elif operation_type == "purchase":
                # Check purchase timing
                raw_material_kg = entry.get('raw_material_kg', 0)
                if raw_material_kg > 1000:
                    business_validation['suggestions'].append("Large purchase - ensure adequate storage")
                
                # Check supplier consistency
                supplier = entry.get('supplier', '')
                if supplier and len(supplier) > 50:
                    business_validation['warnings'].append("Unusually long supplier name")
            
            elif operation_type == "production":
                # Check production efficiency
                raw_used = entry.get('raw_material_used', 0)
                production_entries = entry.get('production_entries', [])
                total_output = sum(item.get('total_weight', 0) for item in production_entries)
                
                if raw_used > 0:
                    efficiency = (total_output / raw_used) * 100
                    if efficiency < 85:
                        business_validation['warnings'].append(f"Low production efficiency: {efficiency:.1f}%")
                    elif efficiency > 98:
                        business_validation['warnings'].append("Unusually high efficiency - verify measurements")
            
            return business_validation
            
        except Exception as e:
            return {
                'valid': True,
                'warnings': [f"Business rule validation error: {str(e)}"],
                'suggestions': []
            }
    
    def _get_expected_price(self, weight: str) -> Optional[float]:
        """Get expected price for a product weight"""
        # Sample pricing logic - adjust based on your business
        price_map = {
            '0.2': 20,
            '0.5': 45,
            '1.0': 85,
            '1.5': 120,
            '2.0': 155
        }
        return price_map.get(weight)