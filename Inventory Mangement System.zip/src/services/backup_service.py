"""
Backup Service - Handles backup and restore operations
"""

import os
import shutil
import schedule
import time
from datetime import datetime, timedelta
from pathlib import Path
from typing import List, Dict, Any, Optional
import logging
import threading
import config

class BackupService:
    """Service for managing backups and restore operations"""
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.backup_dir = config.EXPORTS_DIR
        self.max_backups = config.BACKUP_CONFIG.get('MAX_BACKUPS', 50)
        self.auto_backup_enabled = config.BACKUP_CONFIG.get('AUTO_BACKUP', True)
        self.backup_interval = config.BACKUP_CONFIG.get('BACKUP_INTERVAL', 3600)  # seconds
        
        # Ensure backup directory exists
        self.backup_dir.mkdir(parents=True, exist_ok=True)
        
        # Start auto backup if enabled
        if self.auto_backup_enabled:
            self._setup_auto_backup()
    
    def create_manual_backup(self, source_file: Optional[str] = None) -> bool:
        """Create a manual backup"""
        try:
            from src.services.excel_service import ExcelService
            
            if source_file is None:
                # Use default Excel service file
                excel_service = ExcelService()
                source_file = excel_service.excel_file_path
            
            if not os.path.exists(source_file):
                self.logger.error(f"Source file not found: {source_file}")
                return False
            
            # Generate backup filename
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            source_name = Path(source_file).stem
            backup_filename = f"manual_backup_{source_name}_{timestamp}.xlsx"
            backup_path = self.backup_dir / backup_filename
            
            # Create backup
            shutil.copy2(source_file, backup_path)
            
            # Clean up old backups
            self._cleanup_old_backups()
            
            self.logger.info(f"Manual backup created: {backup_path}")
            return True
            
        except Exception as e:
            self.logger.error(f"Error creating manual backup: {str(e)}")
            return False
    
    def create_auto_backup(self, source_file: Optional[str] = None) -> bool:
        """Create an automatic backup"""
        try:
            from src.services.excel_service import ExcelService
            
            if source_file is None:
                excel_service = ExcelService()
                source_file = excel_service.excel_file_path
            
            if not os.path.exists(source_file):
                self.logger.warning(f"Source file not found for auto backup: {source_file}")
                return False
            
            # Generate backup filename
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            source_name = Path(source_file).stem
            backup_filename = f"auto_backup_{source_name}_{timestamp}.xlsx"
            backup_path = self.backup_dir / backup_filename
            
            # Create backup
            shutil.copy2(source_file, backup_path)
            
            # Clean up old backups
            self._cleanup_old_backups()
            
            self.logger.info(f"Auto backup created: {backup_path}")
            return True
            
        except Exception as e:
            self.logger.error(f"Error creating auto backup: {str(e)}")
            return False
    
    def restore_from_backup(self, backup_file: str, target_file: Optional[str] = None) -> bool:
        """Restore from a backup file"""
        try:
            backup_path = Path(backup_file)
            
            if not backup_path.exists():
                # Try looking in backup directory
                backup_path = self.backup_dir / backup_file
                if not backup_path.exists():
                    self.logger.error(f"Backup file not found: {backup_file}")
                    return False
            
            if target_file is None:
                from src.services.excel_service import ExcelService
                excel_service = ExcelService()
                target_file = excel_service.excel_file_path
            
            # Create backup of current file before restore
            current_backup_name = f"pre_restore_backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
            current_backup_path = self.backup_dir / current_backup_name
            
            if os.path.exists(target_file):
                shutil.copy2(target_file, current_backup_path)
                self.logger.info(f"Created pre-restore backup: {current_backup_path}")
            
            # Restore from backup
            shutil.copy2(backup_path, target_file)
            
            self.logger.info(f"Successfully restored from backup: {backup_file}")
            return True
            
        except Exception as e:
            self.logger.error(f"Error restoring from backup: {str(e)}")
            return False
    
    def list_backups(self) -> List[Dict[str, Any]]:
        """List all available backups"""
        try:
            backups = []
            
            for backup_file in self.backup_dir.glob("*backup*.xlsx"):
                try:
                    stat = backup_file.stat()
                    
                    backup_info = {
                        'filename': backup_file.name,
                        'full_path': str(backup_file),
                        'size': stat.st_size,
                        'size_mb': round(stat.st_size / 1024 / 1024, 2),
                        'created': datetime.fromtimestamp(stat.st_ctime),
                        'modified': datetime.fromtimestamp(stat.st_mtime),
                        'type': self._get_backup_type(backup_file.name),
                        'age_days': (datetime.now() - datetime.fromtimestamp(stat.st_ctime)).days
                    }
                    
                    backups.append(backup_info)
                    
                except Exception as e:
                    self.logger.warning(f"Error processing backup file {backup_file}: {str(e)}")
            
            # Sort by creation time (newest first)
            backups.sort(key=lambda x: x['created'], reverse=True)
            
            return backups
            
        except Exception as e:
            self.logger.error(f"Error listing backups: {str(e)}")
            return []
    
    def delete_backup(self, backup_filename: str) -> bool:
        """Delete a specific backup file"""
        try:
            backup_path = self.backup_dir / backup_filename
            
            if not backup_path.exists():
                self.logger.error(f"Backup file not found: {backup_filename}")
                return False
            
            # Safety check - don't delete if it's the only backup
            all_backups = self.list_backups()
            if len(all_backups) <= 1:
                self.logger.warning("Cannot delete the last remaining backup")
                return False
            
            backup_path.unlink()
            self.logger.info(f"Deleted backup: {backup_filename}")
            return True
            
        except Exception as e:
            self.logger.error(f"Error deleting backup: {str(e)}")
            return False
    
    def get_backup_info(self, backup_filename: str) -> Optional[Dict[str, Any]]:
        """Get detailed information about a specific backup"""
        try:
            backup_path = self.backup_dir / backup_filename
            
            if not backup_path.exists():
                return None
            
            stat = backup_path.stat()
            
            # Try to read Excel file info
            excel_info = {}
            try:
                import openpyxl
                wb = openpyxl.load_workbook(backup_path, read_only=True)
                excel_info = {
                    'sheets': wb.sheetnames,
                    'sheet_count': len(wb.sheetnames)
                }
                wb.close()
            except Exception as e:
                excel_info = {'error': f"Could not read Excel info: {str(e)}"}
            
            backup_info = {
                'filename': backup_path.name,
                'full_path': str(backup_path),
                'size': stat.st_size,
                'size_mb': round(stat.st_size / 1024 / 1024, 2),
                'created': datetime.fromtimestamp(stat.st_ctime),
                'modified': datetime.fromtimestamp(stat.st_mtime),
                'type': self._get_backup_type(backup_path.name),
                'age_days': (datetime.now() - datetime.fromtimestamp(stat.st_ctime)).days,
                'excel_info': excel_info
            }
            
            return backup_info
            
        except Exception as e:
            self.logger.error(f"Error getting backup info: {str(e)}")
            return None
    
    def _cleanup_old_backups(self):
        """Remove old backup files to maintain storage limits"""
        try:
            backups = self.list_backups()
            
            if len(backups) <= self.max_backups:
                return
            
            # Remove oldest backups beyond the limit
            backups_to_remove = backups[self.max_backups:]
            
            for backup in backups_to_remove:
                try:
                    backup_path = Path(backup['full_path'])
                    backup_path.unlink()
                    self.logger.info(f"Cleaned up old backup: {backup['filename']}")
                except Exception as e:
                    self.logger.error(f"Error removing old backup {backup['filename']}: {str(e)}")
                    
        except Exception as e:
            self.logger.error(f"Error cleaning up old backups: {str(e)}")
    
    def _get_backup_type(self, filename: str) -> str:
        """Determine backup type from filename"""
        if 'manual_backup' in filename:
            return 'Manual'
        elif 'auto_backup' in filename:
            return 'Automatic'
        elif 'pre_restore_backup' in filename:
            return 'Pre-Restore'
        else:
            return 'Unknown'
    
    def _setup_auto_backup(self):
        """Setup automatic backup scheduling"""
        try:
            # Schedule auto backup
            schedule.every(self.backup_interval).seconds.do(self.create_auto_backup)
            
            # Start scheduler in background thread
            def run_scheduler():
                while True:
                    schedule.run_pending()
                    time.sleep(60)  # Check every minute
            
            scheduler_thread = threading.Thread(target=run_scheduler, daemon=True)
            scheduler_thread.start()
            
            self.logger.info(f"Auto backup scheduled every {self.backup_interval} seconds")
            
        except Exception as e:
            self.logger.error(f"Error setting up auto backup: {str(e)}")
    
    def create_backup_report(self) -> Dict[str, Any]:
        """Generate a comprehensive backup report"""
        try:
            backups = self.list_backups()
            
            if not backups:
                return {
                    'total_backups': 0,
                    'total_size_mb': 0,
                    'oldest_backup': None,
                    'newest_backup': None,
                    'backup_types': {},
                    'storage_usage': 'No backups found'
                }
            
            # Calculate statistics
            total_size = sum(backup['size'] for backup in backups)
            backup_types = {}
            
            for backup in backups:
                backup_type = backup['type']
                if backup_type not in backup_types:
                    backup_types[backup_type] = {'count': 0, 'size_mb': 0}
                backup_types[backup_type]['count'] += 1
                backup_types[backup_type]['size_mb'] += backup['size_mb']
            
            # Find oldest and newest
            oldest_backup = min(backups, key=lambda x: x['created'])
            newest_backup = max(backups, key=lambda x: x['created'])
            
            report = {
                'total_backups': len(backups),
                'total_size_mb': round(total_size / 1024 / 1024, 2),
                'oldest_backup': {
                    'filename': oldest_backup['filename'],
                    'created': oldest_backup['created'],
                    'age_days': oldest_backup['age_days']
                },
                'newest_backup': {
                    'filename': newest_backup['filename'],
                    'created': newest_backup['created'],
                    'age_days': newest_backup['age_days']
                },
                'backup_types': backup_types,
                'storage_usage': f"{round(total_size / 1024 / 1024, 2)} MB used",
                'auto_backup_enabled': self.auto_backup_enabled,
                'backup_interval_hours': self.backup_interval / 3600,
                'max_backups_limit': self.max_backups
            }
            
            return report
            
        except Exception as e:
            self.logger.error(f"Error creating backup report: {str(e)}")
            return {'error': str(e)}
    
    def verify_backup_integrity(self, backup_filename: str) -> Dict[str, Any]:
        """Verify the integrity of a backup file"""
        try:
            backup_path = self.backup_dir / backup_filename
            
            if not backup_path.exists():
                return {
                    'valid': False,
                    'error': 'Backup file not found',
                    'checks': {}
                }
            
            checks = {}
            
            # Check file size
            file_size = backup_path.stat().st_size
            checks['file_size'] = {
                'passed': file_size > 0,
                'value': f"{round(file_size / 1024, 2)} KB",
                'message': 'File has content' if file_size > 0 else 'File is empty'
            }
            
            # Check if it's a valid Excel file
            try:
                import openpyxl
                wb = openpyxl.load_workbook(backup_path, read_only=True)
                
                checks['excel_format'] = {
                    'passed': True,
                    'value': f"{len(wb.sheetnames)} sheets",
                    'message': f"Valid Excel file with sheets: {', '.join(wb.sheetnames)}"
                }
                
                # Check if required sheets exist
                required_sheets = list(config.SHEET_NAMES.values())
                missing_sheets = [sheet for sheet in required_sheets if sheet not in wb.sheetnames]
                
                checks['required_sheets'] = {
                    'passed': len(missing_sheets) == 0,
                    'value': f"{len(required_sheets) - len(missing_sheets)}/{len(required_sheets)} found",
                    'message': f"Missing sheets: {missing_sheets}" if missing_sheets else "All required sheets present"
                }
                
                wb.close()
                
            except Exception as e:
                checks['excel_format'] = {
                    'passed': False,
                    'value': 'Invalid',
                    'message': f"Excel format error: {str(e)}"
                }
            
            # Check file modification time (ensure it's not corrupted during transfer)
            mod_time = datetime.fromtimestamp(backup_path.stat().st_mtime)
            time_diff = abs((datetime.now() - mod_time).total_seconds())
            
            checks['timestamp_consistency'] = {
                'passed': time_diff < 86400,  # Within 24 hours is reasonable
                'value': mod_time.strftime("%Y-%m-%d %H:%M:%S"),
                'message': 'Timestamp looks reasonable' if time_diff < 86400 else 'Unusual timestamp'
            }
            
            # Overall validity
            all_critical_passed = all(
                check['passed'] for key, check in checks.items() 
                if key in ['file_size', 'excel_format']
            )
            
            return {
                'valid': all_critical_passed,
                'checks': checks,
                'summary': f"{'Valid' if all_critical_passed else 'Invalid'} backup file"
            }
            
        except Exception as e:
            self.logger.error(f"Error verifying backup integrity: {str(e)}")
            return {
                'valid': False,
                'error': str(e),
                'checks': {}
            }

# Global functions for use in other modules
def create_backup_directories():
    """Create necessary backup directories"""
    try:
        config.EXPORTS_DIR.mkdir(parents=True, exist_ok=True)
        config.UPLOADS_DIR.mkdir(parents=True, exist_ok=True)
        config.LOGS_DIR.mkdir(parents=True, exist_ok=True)
    except Exception as e:
        logging.error(f"Error creating backup directories: {str(e)}")

def create_manual_backup() -> bool:
    """Convenience function to create manual backup"""
    try:
        backup_service = BackupService()
        return backup_service.create_manual_backup()
    except Exception as e:
        logging.error(f"Error in manual backup: {str(e)}")
        return False