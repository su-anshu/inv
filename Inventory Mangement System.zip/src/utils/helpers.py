"""
Helper utility functions for the Inventory Management System
"""

import streamlit as st
import pandas as pd
import uuid
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Any, Optional
import json
import logging
import config

def initialize_session_state():
    """Initialize Streamlit session state variables"""
    
    # Session management
    if 'session_id' not in st.session_state:
        st.session_state.session_id = str(uuid.uuid4())
    
    if 'user_name' not in st.session_state:
        st.session_state.user_name = "System User"
    
    if 'login_time' not in st.session_state:
        st.session_state.login_time = datetime.now()
    
    # Data management
    if 'current_excel_file' not in st.session_state:
        st.session_state.current_excel_file = None
    
    if 'last_update' not in st.session_state:
        st.session_state.last_update = "Never"
    
    if 'refresh_data' not in st.session_state:
        st.session_state.refresh_data = False
    
    # UI state
    if 'show_quick_export' not in st.session_state:
        st.session_state.show_quick_export = False
    
    if 'dev_mode' not in st.session_state:
        st.session_state.dev_mode = False
    
    # Cache and performance
    if 'data_cache' not in st.session_state:
        st.session_state.data_cache = {}
    
    if 'cache_timestamps' not in st.session_state:
        st.session_state.cache_timestamps = {}
    
    # Alerts and notifications
    if 'alerts' not in st.session_state:
        st.session_state.alerts = []
    
    if 'quick_stats' not in st.session_state:
        st.session_state.quick_stats = {
            'total_products': 0,
            'low_stock_items': 0,
            'pending_orders': 0,
            'today_sales': 0
        }
    
    # Form states
    if 'form_data' not in st.session_state:
        st.session_state.form_data = {}

def load_custom_css():
    """Load custom CSS styles"""
    try:
        css_file = config.STATIC_DIR / "css" / "custom.css"
        if css_file.exists():
            with open(css_file, 'r') as f:
                st.markdown(f"<style>{f.read()}</style>", unsafe_allow_html=True)
        else:
            # Default CSS if file doesn't exist
            default_css = """
            <style>
            .metric-card {
                background-color: #f0f2f6;
                padding: 1rem;
                border-radius: 0.5rem;
                border-left: 4px solid #ff4b4b;
            }
            
            .success-message {
                padding: 0.75rem;
                background-color: #d4edda;
                border: 1px solid #c3e6cb;
                border-radius: 0.25rem;
                color: #155724;
            }
            
            .warning-message {
                padding: 0.75rem;
                background-color: #fff3cd;
                border: 1px solid #ffeaa7;
                border-radius: 0.25rem;
                color: #856404;
            }
            
            .error-message {
                padding: 0.75rem;
                background-color: #f8d7da;
                border: 1px solid #f5c6cb;
                border-radius: 0.25rem;
                color: #721c24;
            }
            
            .info-box {
                padding: 1rem;
                background-color: #d1ecf1;
                border: 1px solid #bee5eb;
                border-radius: 0.25rem;
                margin: 1rem 0;
            }
            
            .data-table {
                border-collapse: collapse;
                width: 100%;
            }
            
            .data-table th, .data-table td {
                text-align: left;
                padding: 8px;
                border-bottom: 1px solid #ddd;
            }
            
            .data-table th {
                background-color: #f2f2f2;
                font-weight: bold;
            }
            
            .sidebar-metric {
                text-align: center;
                padding: 0.5rem;
                margin: 0.25rem 0;
                background-color: #f8f9fa;
                border-radius: 0.25rem;
            }
            </style>
            """
            st.markdown(default_css, unsafe_allow_html=True)
    except Exception as e:
        logging.error(f"Error loading CSS: {str(e)}")

def get_system_status() -> Dict[str, Any]:
    """Get current system status"""
    try:
        from src.services.excel_service import ExcelService
        
        excel_service = ExcelService()
        
        status = {
            'excel_connected': excel_service.check_excel_connection(),
            'backup_status': True,  # Simplified for now
            'last_update': st.session_state.get('last_update', 'Never'),
            'session_active': True,
            'cache_size': len(st.session_state.get('data_cache', {})),
            'uptime': str(datetime.now() - st.session_state.get('login_time', datetime.now()))
        }
        
        return status
        
    except Exception as e:
        logging.error(f"Error getting system status: {str(e)}")
        return {
            'excel_connected': False,
            'backup_status': False,
            'last_update': 'Error',
            'session_active': False,
            'cache_size': 0,
            'uptime': '0:00:00'
        }

def format_currency(amount: float, currency: str = "₹") -> str:
    """Format currency values"""
    try:
        if amount >= 10000000:  # 1 crore
            return f"{currency}{amount/10000000:.1f}Cr"
        elif amount >= 100000:  # 1 lakh
            return f"{currency}{amount/100000:.1f}L"
        elif amount >= 1000:
            return f"{currency}{amount/1000:.1f}K"
        else:
            return f"{currency}{amount:,.0f}"
    except:
        return f"{currency}0"

def format_number(number: float, decimal_places: int = 0) -> str:
    """Format numbers with appropriate suffixes"""
    try:
        if number >= 1000000:
            return f"{number/1000000:.{decimal_places}f}M"
        elif number >= 1000:
            return f"{number/1000:.{decimal_places}f}K"
        else:
            return f"{number:.{decimal_places}f}"
    except:
        return "0"

def calculate_percentage_change(current: float, previous: float) -> float:
    """Calculate percentage change between two values"""
    try:
        if previous == 0:
            return 100.0 if current > 0 else 0.0
        return ((current - previous) / previous) * 100
    except:
        return 0.0

def get_date_range_options() -> Dict[str, Any]:
    """Get predefined date range options"""
    today = datetime.now().date()
    
    return {
        "Today": (today, today),
        "Yesterday": (today - timedelta(days=1), today - timedelta(days=1)),
        "Last 7 Days": (today - timedelta(days=7), today),
        "Last 30 Days": (today - timedelta(days=30), today),
        "This Month": (today.replace(day=1), today),
        "Last Month": (
            (today.replace(day=1) - timedelta(days=1)).replace(day=1),
            today.replace(day=1) - timedelta(days=1)
        ),
        "This Year": (today.replace(month=1, day=1), today),
        "Custom": None  # Will be handled separately
    }

def validate_date_range(start_date, end_date) -> bool:
    """Validate date range"""
    try:
        if not start_date or not end_date:
            return False
        
        if start_date > end_date:
            return False
        
        if end_date > datetime.now().date():
            return False
        
        # Check if range is not too large (e.g., more than 2 years)
        if (end_date - start_date).days > 730:
            return False
        
        return True
    except:
        return False

def cache_data(key: str, data: Any, ttl_seconds: int = 300):
    """Cache data with TTL (Time To Live)"""
    try:
        if 'data_cache' not in st.session_state:
            st.session_state.data_cache = {}
        if 'cache_timestamps' not in st.session_state:
            st.session_state.cache_timestamps = {}
        
        st.session_state.data_cache[key] = data
        st.session_state.cache_timestamps[key] = datetime.now() + timedelta(seconds=ttl_seconds)
        
    except Exception as e:
        logging.error(f"Error caching data: {str(e)}")

def get_cached_data(key: str) -> Optional[Any]:
    """Get cached data if still valid"""
    try:
        if key not in st.session_state.get('data_cache', {}):
            return None
        
        if key not in st.session_state.get('cache_timestamps', {}):
            return None
        
        # Check if cache is still valid
        if datetime.now() > st.session_state.cache_timestamps[key]:
            # Cache expired, remove it
            del st.session_state.data_cache[key]
            del st.session_state.cache_timestamps[key]
            return None
        
        return st.session_state.data_cache[key]
        
    except Exception as e:
        logging.error(f"Error getting cached data: {str(e)}")
        return None

def clear_cache(key: Optional[str] = None):
    """Clear cache data"""
    try:
        if key:
            # Clear specific key
            if key in st.session_state.get('data_cache', {}):
                del st.session_state.data_cache[key]
            if key in st.session_state.get('cache_timestamps', {}):
                del st.session_state.cache_timestamps[key]
        else:
            # Clear all cache
            st.session_state.data_cache = {}
            st.session_state.cache_timestamps = {}
            
    except Exception as e:
        logging.error(f"Error clearing cache: {str(e)}")

def export_session_data() -> Dict[str, Any]:
    """Export session data for debugging"""
    try:
        export_data = {
            'session_id': st.session_state.get('session_id'),
            'user_name': st.session_state.get('user_name'),
            'login_time': str(st.session_state.get('login_time')),
            'last_update': st.session_state.get('last_update'),
            'alerts_count': len(st.session_state.get('alerts', [])),
            'cache_keys': list(st.session_state.get('data_cache', {}).keys()),
            'quick_stats': st.session_state.get('quick_stats', {}),
            'current_excel_file': st.session_state.get('current_excel_file')
        }
        
        return export_data
        
    except Exception as e:
        logging.error(f"Error exporting session data: {str(e)}")
        return {}

def log_user_action(action: str, details: Dict[str, Any] = None):
    """Log user actions for audit trail"""
    try:
        log_entry = {
            'timestamp': datetime.now().isoformat(),
            'session_id': st.session_state.get('session_id'),
            'user': st.session_state.get('user_name', 'Unknown'),
            'action': action,
            'details': details or {}
        }
        
        # Write to log file
        log_file = config.LOGS_DIR / "user_actions.log"
        with open(log_file, 'a') as f:
            f.write(json.dumps(log_entry) + '\n')
            
    except Exception as e:
        logging.error(f"Error logging user action: {str(e)}")

def generate_report_filename(report_type: str, format_type: str = "xlsx") -> str:
    """Generate standardized report filename"""
    try:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        user = st.session_state.get('user_name', 'system').replace(' ', '_').lower()
        
        filename = f"{report_type}_report_{user}_{timestamp}.{format_type}"
        return filename
        
    except Exception as e:
        logging.error(f"Error generating filename: {str(e)}")
        return f"{report_type}_report.{format_type}"

def sanitize_filename(filename: str) -> str:
    """Sanitize filename for safe file operations"""
    try:
        import re
        
        # Remove unsafe characters
        filename = re.sub(r'[<>:"/\\|?*]', '_', filename)
        
        # Remove leading/trailing whitespace and dots
        filename = filename.strip(' .')
        
        # Limit length
        if len(filename) > 200:
            name, ext = filename.rsplit('.', 1) if '.' in filename else (filename, '')
            filename = name[:190] + '.' + ext if ext else name[:200]
        
        return filename
        
    except Exception as e:
        logging.error(f"Error sanitizing filename: {str(e)}")
        return "safe_filename.txt"

def create_download_link(file_path: str, link_text: str = "Download") -> str:
    """Create a download link for files"""
    try:
        import base64
        
        with open(file_path, "rb") as f:
            data = f.read()
        
        b64 = base64.b64encode(data).decode()
        filename = Path(file_path).name
        
        href = f'<a href="data:application/octet-stream;base64,{b64}" download="{filename}">{link_text}</a>'
        return href
        
    except Exception as e:
        logging.error(f"Error creating download link: {str(e)}")
        return f"Error: Could not create download link"

def show_notification(message: str, notification_type: str = "info", duration: int = 5):
    """Show temporary notification to user"""
    try:
        if notification_type == "success":
            st.success(message)
        elif notification_type == "error":
            st.error(message)
        elif notification_type == "warning":
            st.warning(message)
        else:
            st.info(message)
        
        # Store notification for persistence across reruns
        if 'notifications' not in st.session_state:
            st.session_state.notifications = []
        
        notification = {
            'message': message,
            'type': notification_type,
            'timestamp': datetime.now(),
            'duration': duration
        }
        
        st.session_state.notifications.append(notification)
        
        # Clean old notifications
        current_time = datetime.now()
        st.session_state.notifications = [
            n for n in st.session_state.notifications
            if (current_time - n['timestamp']).seconds < n['duration']
        ]
        
    except Exception as e:
        logging.error(f"Error showing notification: {str(e)}")

def get_file_size_display(file_path: str) -> str:
    """Get human-readable file size"""
    try:
        size = Path(file_path).stat().st_size
        
        for unit in ['B', 'KB', 'MB', 'GB']:
            if size < 1024.0:
                return f"{size:.1f} {unit}"
            size /= 1024.0
        
        return f"{size:.1f} TB"
        
    except Exception as e:
        logging.error(f"Error getting file size: {str(e)}")
        return "Unknown"

def validate_excel_upload(uploaded_file) -> Dict[str, Any]:
    """Validate uploaded Excel file"""
    try:
        validation_result = {
            'valid': True,
            'errors': [],
            'warnings': [],
            'file_info': {}
        }
        
        if uploaded_file is None:
            validation_result['valid'] = False
            validation_result['errors'].append("No file uploaded")
            return validation_result
        
        # Check file extension
        if not uploaded_file.name.lower().endswith(('.xlsx', '.xls')):
            validation_result['valid'] = False
            validation_result['errors'].append("File must be Excel format (.xlsx or .xls)")
            return validation_result
        
        # Check file size
        file_size = len(uploaded_file.getvalue())
        if file_size > 50 * 1024 * 1024:  # 50MB limit
            validation_result['valid'] = False
            validation_result['errors'].append("File size too large (max 50MB)")
            return validation_result
        
        # Try to read the file
        try:
            df = pd.read_excel(uploaded_file)
            
            validation_result['file_info'] = {
                'filename': uploaded_file.name,
                'size': get_file_size_display(uploaded_file.name),
                'rows': len(df),
                'columns': len(df.columns),
                'sheets': 1  # Basic check, could be enhanced
            }
            
            if df.empty:
                validation_result['warnings'].append("File appears to be empty")
            
        except Exception as e:
            validation_result['valid'] = False
            validation_result['errors'].append(f"Could not read Excel file: {str(e)}")
        
        return validation_result
        
    except Exception as e:
        return {
            'valid': False,
            'errors': [f"Validation error: {str(e)}"],
            'warnings': [],
            'file_info': {}
        }

def create_backup_filename(original_filename: str) -> str:
    """Create backup filename with timestamp"""
    try:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        name, ext = original_filename.rsplit('.', 1) if '.' in original_filename else (original_filename, 'bak')
        return f"{name}_backup_{timestamp}.{ext}"
        
    except Exception as e:
        logging.error(f"Error creating backup filename: {str(e)}")
        return f"backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}.bak"

def format_datetime(dt: datetime, format_type: str = "full") -> str:
    """Format datetime for display"""
    try:
        if format_type == "full":
            return dt.strftime("%Y-%m-%d %H:%M:%S")
        elif format_type == "date":
            return dt.strftime("%Y-%m-%d")
        elif format_type == "time":
            return dt.strftime("%H:%M:%S")
        elif format_type == "relative":
            now = datetime.now()
            diff = now - dt
            
            if diff.days > 0:
                return f"{diff.days} days ago"
            elif diff.seconds > 3600:
                hours = diff.seconds // 3600
                return f"{hours} hours ago"
            elif diff.seconds > 60:
                minutes = diff.seconds // 60
                return f"{minutes} minutes ago"
            else:
                return "Just now"
        else:
            return dt.strftime("%Y-%m-%d %H:%M")
            
    except Exception as e:
        logging.error(f"Error formatting datetime: {str(e)}")
        return str(dt)

def get_stock_status_color(stock_level: int) -> str:
    """Get color code based on stock level"""
    try:
        if stock_level <= config.DASHBOARD_CONFIG['CRITICAL_STOCK_THRESHOLD']:
            return "#FF4444"  # Red
        elif stock_level <= config.DASHBOARD_CONFIG['LOW_STOCK_THRESHOLD']:
            return "#FF8800"  # Orange
        else:
            return "#00AA44"  # Green
            
    except:
        return "#888888"  # Gray

def calculate_reorder_point(avg_daily_usage: float, lead_time_days: int, safety_stock: int = 5) -> int:
    """Calculate reorder point for inventory"""
    try:
        reorder_point = (avg_daily_usage * lead_time_days) + safety_stock
        return max(int(reorder_point), safety_stock)
        
    except:
        return safety_stock

def generate_product_code(product_name: str, weight: str) -> str:
    """Generate standardized product code"""
    try:
        # Extract first letters of product name
        name_code = ''.join([word[0].upper() for word in product_name.split() if word])
        
        # Format weight
        weight_str = str(weight).replace('.', '')
        
        # Generate code
        product_code = f"{name_code}{weight_str}"
        
        return product_code
        
    except Exception as e:
        logging.error(f"Error generating product code: {str(e)}")
        return "UNKNOWN"

def create_data_summary(df: pd.DataFrame) -> Dict[str, Any]:
    """Create summary statistics for DataFrame"""
    try:
        if df.empty:
            return {'error': 'No data available'}
        
        summary = {
            'total_rows': len(df),
            'total_columns': len(df.columns),
            'numeric_columns': list(df.select_dtypes(include=['number']).columns),
            'text_columns': list(df.select_dtypes(include=['object']).columns),
            'date_columns': list(df.select_dtypes(include=['datetime']).columns),
            'missing_values': df.isnull().sum().to_dict(),
            'data_types': df.dtypes.to_dict()
        }
        
        # Add numeric summaries
        if summary['numeric_columns']:
            numeric_summary = df[summary['numeric_columns']].describe().to_dict()
            summary['numeric_summary'] = numeric_summary
        
        return summary
        
    except Exception as e:
        logging.error(f"Error creating data summary: {str(e)}")
        return {'error': str(e)}

def apply_dataframe_styling(df: pd.DataFrame, style_type: str = "default") -> pd.DataFrame:
    """Apply styling to DataFrame for better display"""
    try:
        if style_type == "financial":
            # Format financial data
            numeric_columns = df.select_dtypes(include=['number']).columns
            for col in numeric_columns:
                if 'price' in col.lower() or 'amount' in col.lower() or 'value' in col.lower():
                    df[col] = df[col].apply(lambda x: f"₹{x:,.2f}" if pd.notnull(x) else "")
        
        elif style_type == "percentage":
            # Format percentage columns
            for col in df.columns:
                if 'percent' in col.lower() or '%' in col:
                    df[col] = df[col].apply(lambda x: f"{x:.1f}%" if pd.notnull(x) else "")
        
        elif style_type == "stock":
            # Format stock-related data
            if 'Stock' in df.columns:
                df['Stock Status'] = df['Stock'].apply(
                    lambda x: "🟢 Good" if x > 50 else "🟡 Low" if x > 10 else "🔴 Critical"
                )
        
        return df
        
    except Exception as e:
        logging.error(f"Error applying DataFrame styling: {str(e)}")
        return df

def create_progress_bar(current: int, total: int, label: str = "") -> str:
    """Create HTML progress bar"""
    try:
        if total == 0:
            percentage = 0
        else:
            percentage = min((current / total) * 100, 100)
        
        color = "#00AA44" if percentage >= 70 else "#FF8800" if percentage >= 40 else "#FF4444"
        
        html = f"""
        <div style="margin: 10px 0;">
            {f"<label>{label}</label>" if label else ""}
            <div style="background-color: #f0f0f0; border-radius: 10px; overflow: hidden;">
                <div style="width: {percentage}%; height: 20px; background-color: {color}; 
                     text-align: center; line-height: 20px; color: white; font-weight: bold;">
                    {percentage:.1f}%
                </div>
            </div>
            <small>{current} / {total}</small>
        </div>
        """
        
        return html
        
    except Exception as e:
        logging.error(f"Error creating progress bar: {str(e)}")
        return f"<div>Progress: {current}/{total}</div>"

def handle_file_upload(uploaded_file, destination_dir: Path, allowed_extensions: List[str] = None) -> Dict[str, Any]:
    """Handle file upload with validation"""
    try:
        result = {
            'success': False,
            'file_path': None,
            'error': None,
            'file_info': {}
        }
        
        if uploaded_file is None:
            result['error'] = "No file uploaded"
            return result
        
        # Check file extension
        file_extension = uploaded_file.name.split('.')[-1].lower()
        if allowed_extensions and file_extension not in allowed_extensions:
            result['error'] = f"File type not allowed. Allowed: {', '.join(allowed_extensions)}"
            return result
        
        # Create destination directory if it doesn't exist
        destination_dir.mkdir(parents=True, exist_ok=True)
        
        # Generate safe filename
        safe_filename = sanitize_filename(uploaded_file.name)
        file_path = destination_dir / safe_filename
        
        # Handle duplicate filenames
        counter = 1
        original_path = file_path
        while file_path.exists():
            name, ext = original_path.stem, original_path.suffix
            file_path = destination_dir / f"{name}_{counter}{ext}"
            counter += 1
        
        # Save file
        with open(file_path, "wb") as f:
            f.write(uploaded_file.getbuffer())
        
        result.update({
            'success': True,
            'file_path': str(file_path),
            'file_info': {
                'original_name': uploaded_file.name,
                'saved_name': file_path.name,
                'size': len(uploaded_file.getbuffer()),
                'size_display': get_file_size_display(str(file_path)),
                'upload_time': datetime.now().isoformat()
            }
        })
        
        return result
        
    except Exception as e:
        logging.error(f"Error handling file upload: {str(e)}")
        return {
            'success': False,
            'file_path': None,
            'error': str(e),
            'file_info': {}
        }

def cleanup_temp_files(directory: Path, max_age_hours: int = 24):
    """Clean up temporary files older than specified hours"""
    try:
        if not directory.exists():
            return
        
        cutoff_time = datetime.now() - timedelta(hours=max_age_hours)
        
        for file_path in directory.iterdir():
            if file_path.is_file():
                file_modified_time = datetime.fromtimestamp(file_path.stat().st_mtime)
                if file_modified_time < cutoff_time:
                    file_path.unlink()
                    logging.info(f"Cleaned up temp file: {file_path}")
                    
    except Exception as e:
        logging.error(f"Error cleaning up temp files: {str(e)}")

def generate_qr_code(data: str, size: int = 200) -> str:
    """Generate QR code for data"""
    try:
        import qrcode
        import io
        import base64
        from PIL import Image
        
        qr = qrcode.QRCode(version=1, box_size=10, border=5)
        qr.add_data(data)
        qr.make(fit=True)
        
        img = qr.make_image(fill_color="black", back_color="white")
        
        # Convert to base64 for display
        buffer = io.BytesIO()
        img.save(buffer, format='PNG')
        img_str = base64.b64encode(buffer.getvalue()).decode()
        
        return f"data:image/png;base64,{img_str}"
        
    except ImportError:
        return "QR code generation not available (qrcode library not installed)"
    except Exception as e:
        logging.error(f"Error generating QR code: {str(e)}")
        return "Error generating QR code"

def create_alert_message(message: str, alert_type: str = "info", dismissible: bool = True) -> str:
    """Create styled alert message HTML"""
    try:
        colors = {
            'success': {'bg': '#d4edda', 'border': '#c3e6cb', 'text': '#155724'},
            'warning': {'bg': '#fff3cd', 'border': '#ffeaa7', 'text': '#856404'},
            'error': {'bg': '#f8d7da', 'border': '#f5c6cb', 'text': '#721c24'},
            'info': {'bg': '#d1ecf1', 'border': '#bee5eb', 'text': '#0c5460'}
        }
        
        color_scheme = colors.get(alert_type, colors['info'])
        
        dismiss_button = """
        <button type="button" style="float: right; background: none; border: none; 
                font-size: 18px; cursor: pointer;" onclick="this.parentElement.style.display='none'">
            &times;
        </button>
        """ if dismissible else ""
        
        html = f"""
        <div style="padding: 0.75rem; margin: 0.5rem 0; background-color: {color_scheme['bg']}; 
             border: 1px solid {color_scheme['border']}; border-radius: 0.25rem; 
             color: {color_scheme['text']};">
            {dismiss_button}
            {message}
        </div>
        """
        
        return html
        
    except Exception as e:
        logging.error(f"Error creating alert message: {str(e)}")
        return f"<div>{message}</div>"