"""
Live Dashboard - Real-time inventory monitoring and analytics
"""

import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from datetime import datetime, timedelta
from src.services.excel_service import ExcelService
from src.services.stock_calculator import StockCalculator
from src.components.dashboard_widgets import (
    create_metric_card,
    create_stock_level_chart,
    create_sales_trend_chart,
    create_channel_performance_chart
)
import config

def show_dashboard():
    """Main dashboard page"""
    
    st.header("📊 Live Dashboard")
    st.markdown("Real-time inventory monitoring and key performance indicators")
    
    # Initialize services
    excel_service = ExcelService()
    calculator = StockCalculator()
    
    # Auto-refresh toggle
    col1, col2, col3 = st.columns([2, 1, 1])
    with col1:
        st.markdown("### Key Performance Indicators")
    with col2:
        auto_refresh = st.toggle("Auto Refresh", value=False)
    with col3:
        if st.button("🔄 Refresh Now", use_container_width=True):
            st.experimental_rerun()
    
    # Auto refresh logic
    if auto_refresh:
        st.experimental_rerun()
    
    # Load current data
    try:
        current_data = excel_service.read_all_data()
        stock_summary = calculator.calculate_stock_summary(current_data)
        sales_data = excel_service.get_sales_data()
    except Exception as e:
        st.error(f"❌ Error loading data: {str(e)}")
        return
    
    # KPI Metrics Row
    show_kpi_metrics(stock_summary, sales_data)
    
    st.markdown("---")
    
    # Charts Section
    col1, col2 = st.columns(2)
    
    with col1:
        show_stock_levels_chart(stock_summary)
        show_low_stock_alerts(stock_summary)
    
    with col2:
        show_sales_trend_chart(sales_data)
        show_channel_performance(sales_data)
    
    st.markdown("---")
    
    # Detailed Tables Section
    show_detailed_tables(current_data, stock_summary)
    
    # Alerts and Notifications
    show_alerts_section(stock_summary, sales_data)

def show_kpi_metrics(stock_summary, sales_data):
    """Display key performance indicator metrics"""
    
    # Calculate KPIs
    total_products = len(stock_summary.get('products', []))
    total_stock_value = stock_summary.get('total_value', 0)
    low_stock_count = len([p for p in stock_summary.get('products', []) 
                          if p.get('stock', 0) < config.DASHBOARD_CONFIG['LOW_STOCK_THRESHOLD']])
    
    today_sales = sum([sale.get('amount', 0) for sale in sales_data.get('today', [])])
    
    # Display metrics in columns
    col1, col2, col3, col4, col5 = st.columns(5)
    
    with col1:
        st.metric(
            label="📦 Total Products",
            value=total_products,
            delta=None,
            help="Total number of product variants"
        )
    
    with col2:
        st.metric(
            label="💰 Stock Value",
            value=f"₹{total_stock_value:,.0f}",
            delta=None,
            help="Total value of current inventory"
        )
    
    with col3:
        st.metric(
            label="⚠️ Low Stock Items",
            value=low_stock_count,
            delta=None,
            delta_color="inverse",
            help=f"Items below {config.DASHBOARD_CONFIG['LOW_STOCK_THRESHOLD']} units"
        )
    
    with col4:
        st.metric(
            label="📈 Today's Sales",
            value=f"₹{today_sales:,.0f}",
            delta=None,
            help="Sales amount for today"
        )
    
    with col5:
        # Calculate stock turnover rate
        avg_daily_sales = sales_data.get('avg_daily_sales', 0)
        turnover_days = total_stock_value / avg_daily_sales if avg_daily_sales > 0 else 0
        
        st.metric(
            label="🔄 Stock Turnover",
            value=f"{turnover_days:.0f} days",
            delta=None,
            help="Days to consume current stock at current sales rate"
        )

def show_stock_levels_chart(stock_summary):
    """Display current stock levels chart"""
    
    st.subheader("📊 Current Stock Levels")
    
    if not stock_summary.get('products'):
        st.warning("No stock data available")
        return
    
    # Prepare data for chart
    products = []
    stock_levels = []
    stock_status = []
    
    for product in stock_summary['products']:
        products.append(f"{product['weight']}kg")
        stock_levels.append(product['stock'])
        
        # Determine status color
        if product['stock'] < config.DASHBOARD_CONFIG['CRITICAL_STOCK_THRESHOLD']:
            stock_status.append('Critical')
        elif product['stock'] < config.DASHBOARD_CONFIG['LOW_STOCK_THRESHOLD']:
            stock_status.append('Low')
        else:
            stock_status.append('Normal')
    
    # Create bar chart
    fig = px.bar(
        x=products,
        y=stock_levels,
        color=stock_status,
        color_discrete_map={
            'Critical': '#FF4444',
            'Low': '#FF8800',
            'Normal': '#00AA44'
        },
        title="Stock Levels by Product Weight",
        labels={'x': 'Product Weight', 'y': 'Stock Quantity'},
    )
    
    fig.update_layout(
        showlegend=True,
        height=300,
        xaxis_title="Product Weight",
        yaxis_title="Stock Quantity"
    )
    
    st.plotly_chart(fig, use_container_width=True)

def show_sales_trend_chart(sales_data):
    """Display sales trend chart"""
    
    st.subheader("📈 Sales Trend (Last 7 Days)")
    
    # Generate sample data for last 7 days
    dates = [(datetime.now() - timedelta(days=i)).strftime('%Y-%m-%d') for i in range(6, -1, -1)]
    sales_amounts = [
        sales_data.get('daily_sales', {}).get(date, 0) 
        for date in dates
    ]
    
    if not any(sales_amounts):
        # Generate sample data if no real data available
        import random
        sales_amounts = [random.randint(5000, 15000) for _ in range(7)]
    
    # Create line chart
    fig = go.Figure()
    fig.add_trace(go.Scatter(
        x=dates,
        y=sales_amounts,
        mode='lines+markers',
        name='Daily Sales',
        line=dict(color='#FF4B4B', width=3),
        marker=dict(size=8)
    ))
    
    fig.update_layout(
        title="Daily Sales Trend",
        xaxis_title="Date",
        yaxis_title="Sales Amount (₹)",
        height=300,
        showlegend=False
    )
    
    st.plotly_chart(fig, use_container_width=True)

def show_channel_performance(sales_data):
    """Display sales channel performance"""
    
    st.subheader("🎯 Channel Performance")
    
    # Sample channel data
    channels = ['Amazon FBA', 'Amazon Easyship', 'Flipkart', 'Others']
    channel_sales = [
        sales_data.get('channel_sales', {}).get(channel, 0)
        for channel in channels
    ]
    
    if not any(channel_sales):
        # Generate sample data
        channel_sales = [45000, 25000, 20000, 10000]
    
    # Create pie chart
    fig = px.pie(
        values=channel_sales,
        names=channels,
        title="Sales Distribution by Channel",
        color_discrete_sequence=['#FF4B4B', '#FF8700', '#00D4AA', '#8B5CF6']
    )
    
    fig.update_traces(textposition='inside', textinfo='percent+label')
    fig.update_layout(height=300)
    
    st.plotly_chart(fig, use_container_width=True)

def show_low_stock_alerts(stock_summary):
    """Display low stock alerts"""
    
    st.subheader("⚠️ Stock Alerts")
    
    low_stock_items = [
        product for product in stock_summary.get('products', [])
        if product.get('stock', 0) < config.DASHBOARD_CONFIG['LOW_STOCK_THRESHOLD']
    ]
    
    if not low_stock_items:
        st.success("✅ All products have sufficient stock!")
        return
    
    # Display alerts
    for item in low_stock_items:
        stock_level = item.get('stock', 0)
        weight = item.get('weight', 'Unknown')
        
        if stock_level < config.DASHBOARD_CONFIG['CRITICAL_STOCK_THRESHOLD']:
            st.error(f"🚨 CRITICAL: {weight}kg - Only {stock_level} units left!")
        else:
            st.warning(f"⚠️ LOW STOCK: {weight}kg - {stock_level} units remaining")

def show_detailed_tables(current_data, stock_summary):
    """Display detailed data tables"""
    
    st.subheader("📋 Detailed Stock Information")
    
    # Create tabs for different views
    tab1, tab2, tab3 = st.tabs(["📦 Current Stock", "📊 Product Performance", "🔄 Recent Transactions"])
    
    with tab1:
        show_current_stock_table(stock_summary)
    
    with tab2:
        show_product_performance_table(current_data)
    
    with tab3:
        show_recent_transactions_table(current_data)

def show_current_stock_table(stock_summary):
    """Display current stock table"""
    
    if not stock_summary.get('products'):
        st.warning("No stock data available")
        return
    
    # Prepare table data
    table_data = []
    for product in stock_summary['products']:
        status = "🟢 Normal"
        if product['stock'] < config.DASHBOARD_CONFIG['CRITICAL_STOCK_THRESHOLD']:
            status = "🔴 Critical"
        elif product['stock'] < config.DASHBOARD_CONFIG['LOW_STOCK_THRESHOLD']:
            status = "🟡 Low"
        
        table_data.append({
            'Product': f"Roasted Chana {product['weight']}kg",
            'Current Stock': product['stock'],
            'Value (₹)': f"₹{product.get('value', 0):,.0f}",
            'Status': status,
            'Last Updated': product.get('last_updated', 'N/A')
        })
    
    df = pd.DataFrame(table_data)
    
    # Display with styling
    st.dataframe(
        df,
        use_container_width=True,
        hide_index=True,
        column_config={
            "Current Stock": st.column_config.NumberColumn(
                "Current Stock",
                help="Current available stock",
                format="%d units"
            ),
            "Value (₹)": st.column_config.TextColumn(
                "Value (₹)",
                help="Total value of current stock"
            )
        }
    )

def show_product_performance_table(current_data):
    """Display product performance analytics"""
    
    # Sample performance data
    performance_data = [
        {
            'Product': 'Roasted Chana 1.0kg',
            'Total Sales': 456,
            'Revenue (₹)': '₹45,600',
            'Contribution (%)': '51%',
            'Avg Daily Sales': 15,
            'Trend': '📈 +12%'
        },
        {
            'Product': 'Roasted Chana 2.0kg', 
            'Total Sales': 154,
            'Revenue (₹)': '₹30,800',
            'Contribution (%)': '34%',
            'Avg Daily Sales': 5,
            'Trend': '📈 +8%'
        },
        {
            'Product': 'Roasted Chana 0.5kg',
            'Total Sales': 106,
            'Revenue (₹)': '₹10,600',
            'Contribution (%)': '6%',
            'Avg Daily Sales': 4,
            'Trend': '📉 -2%'
        },
        {
            'Product': 'Roasted Chana 1.5kg',
            'Total Sales': 46,
            'Revenue (₹)': '₹6,900',
            'Contribution (%)': '8%',
            'Avg Daily Sales': 2,
            'Trend': '📈 +5%'
        },
        {
            'Product': 'Roasted Chana 0.2kg',
            'Total Sales': 53,
            'Revenue (₹)': '₹2,120',
            'Contribution (%)': '1%',
            'Avg Daily Sales': 2,
            'Trend': '📊 0%'
        }
    ]
    
    df = pd.DataFrame(performance_data)
    st.dataframe(df, use_container_width=True, hide_index=True)

def show_recent_transactions_table(current_data):
    """Display recent transactions"""
    
    # Sample transaction data
    transactions = [
        {
            'Date': '2025-06-08',
            'Type': 'Sale',
            'Product': '1.0kg',
            'Quantity': 10,
            'Channel': 'Amazon FBA',
            'Amount (₹)': '₹1,000'
        },
        {
            'Date': '2025-06-08',
            'Type': 'Purchase',
            'Product': 'Raw Material',
            'Quantity': 50,
            'Channel': 'Supplier A',
            'Amount (₹)': '₹2,500'
        },
        {
            'Date': '2025-06-07',
            'Type': 'Production',
            'Product': '0.5kg',
            'Quantity': 20,
            'Channel': 'Internal',
            'Amount (₹)': '-'
        },
        {
            'Date': '2025-06-07',
            'Type': 'Return',
            'Product': '2.0kg',
            'Quantity': 2,
            'Channel': 'Flipkart',
            'Amount (₹)': '₹400'
        },
        {
            'Date': '2025-06-06',
            'Type': 'Sale',
            'Product': '1.5kg',
            'Quantity': 5,
            'Channel': 'Amazon Easyship',
            'Amount (₹)': '₹750'
        }
    ]
    
    df = pd.DataFrame(transactions)
    st.dataframe(df, use_container_width=True, hide_index=True)

def show_alerts_section(stock_summary, sales_data):
    """Display alerts and notifications"""
    
    st.subheader("🔔 Alerts & Notifications")
    
    alerts = []
    
    # Stock alerts
    for product in stock_summary.get('products', []):
        stock = product.get('stock', 0)
        weight = product.get('weight', 'Unknown')
        
        if stock < config.DASHBOARD_CONFIG['CRITICAL_STOCK_THRESHOLD']:
            alerts.append({
                'type': 'error',
                'message': f"Critical stock level for {weight}kg: Only {stock} units left",
                'action': 'Immediate reorder required'
            })
        elif stock < config.DASHBOARD_CONFIG['LOW_STOCK_THRESHOLD']:
            alerts.append({
                'type': 'warning', 
                'message': f"Low stock level for {weight}kg: {stock} units remaining",
                'action': 'Consider reordering'
            })
    
    # Sales performance alerts
    today_sales = sum([sale.get('amount', 0) for sale in sales_data.get('today', [])])
    avg_sales = sales_data.get('avg_daily_sales', 10000)
    
    if today_sales < avg_sales * 0.7:
        alerts.append({
            'type': 'warning',
            'message': f"Today's sales (₹{today_sales:,.0f}) are 30% below average",
            'action': 'Review sales strategy'
        })
    elif today_sales > avg_sales * 1.3:
        alerts.append({
            'type': 'success',
            'message': f"Excellent sales performance today! 30% above average",
            'action': 'Ensure adequate stock for demand'
        })
    
    # System alerts
    if not excel_service.check_excel_connection():
        alerts.append({
            'type': 'error',
            'message': 'Excel file connection lost',
            'action': 'Check file path and permissions'
        })
    
    # Display alerts
    if not alerts:
        st.success("✅ No alerts! Everything is running smoothly.")
    else:
        for alert in alerts:
            if alert['type'] == 'error':
                st.error(f"🚨 {alert['message']} - {alert['action']}")
            elif alert['type'] == 'warning':
                st.warning(f"⚠️ {alert['message']} - {alert['action']}")
            elif alert['type'] == 'success':
                st.success(f"🎉 {alert['message']} - {alert['action']}")
            else:
                st.info(f"ℹ️ {alert['message']} - {alert['action']}")

def show_advanced_analytics():
    """Display advanced analytics section"""
    
    st.subheader("📊 Advanced Analytics")
    
    # Create tabs for different analytics
    tab1, tab2, tab3 = st.tabs(["📈 Forecasting", "💡 Insights", "🎯 Recommendations"])
    
    with tab1:
        show_demand_forecasting()
    
    with tab2:
        show_business_insights()
    
    with tab3:
        show_recommendations()

def show_demand_forecasting():
    """Display demand forecasting charts"""
    
    st.markdown("**📈 Demand Forecasting (Next 7 Days)**")
    
    # Sample forecasting data
    forecast_dates = [(datetime.now() + timedelta(days=i)).strftime('%m-%d') for i in range(1, 8)]
    forecasted_demand = [12, 15, 18, 14, 16, 20, 13]  # Sample data
    
    fig = go.Figure()
    fig.add_trace(go.Scatter(
        x=forecast_dates,
        y=forecasted_demand,
        mode='lines+markers',
        name='Forecasted Demand',
        line=dict(color='#00D4AA', width=3, dash='dash'),
        marker=dict(size=8)
    ))
    
    fig.update_layout(
        title="Predicted Daily Sales Units",
        xaxis_title="Date",
        yaxis_title="Units",
        height=300
    )
    
    st.plotly_chart(fig, use_container_width=True)
    
    # Forecast summary
    total_forecast = sum(forecasted_demand)
    st.info(f"📊 Forecasted demand for next 7 days: {total_forecast} units")

def show_business_insights():
    """Display business insights"""
    
    st.markdown("**💡 Business Insights**")
    
    insights = [
        {
            'title': 'Top Performing Product',
            'value': '1.0kg Roasted Chana',
            'description': 'Contributes 51% of total sales volume',
            'icon': '🏆'
        },
        {
            'title': 'Best Sales Channel',
            'value': 'Amazon FBA',
            'description': 'Highest revenue with 45% share',
            'icon': '📈'
        },
        {
            'title': 'Peak Sales Day',
            'value': 'Saturday',
            'description': 'Average 25% higher sales on weekends',
            'icon': '📅'
        },
        {
            'title': 'Inventory Turnover',
            'value': '15 days',
            'description': 'Stock moves efficiently',
            'icon': '🔄'
        }
    ]
    
    for insight in insights:
        col1, col2 = st.columns([1, 4])
        with col1:
            st.markdown(f"## {insight['icon']}")
        with col2:
            st.markdown(f"**{insight['title']}**: {insight['value']}")
            st.caption(insight['description'])
        st.markdown("---")

def show_recommendations():
    """Display automated recommendations"""
    
    st.markdown("**🎯 Smart Recommendations**")
    
    recommendations = [
        {
            'type': 'Inventory',
            'priority': 'High',
            'message': 'Reorder 1.0kg pouches - predicted stockout in 3 days',
            'action': 'Order 100 units immediately'
        },
        {
            'type': 'Pricing',
            'priority': 'Medium', 
            'message': '0.2kg variant has low demand - consider bundling',
            'action': 'Create combo packs with popular sizes'
        },
        {
            'type': 'Production',
            'priority': 'Medium',
            'message': 'Weekend demand spike expected',
            'action': 'Schedule production for Friday'
        },
        {
            'type': 'Marketing',
            'priority': 'Low',
            'message': 'Flipkart channel underperforming',
            'action': 'Review pricing and promotions'
        }
    ]
    
    for rec in recommendations:
        priority_color = {
            'High': 'error',
            'Medium': 'warning', 
            'Low': 'info'
        }
        
        with st.container():
            col1, col2, col3 = st.columns([1, 3, 2])
            with col1:
                getattr(st, priority_color[rec['priority']])(rec['priority'])
            with col2:
                st.write(f"**{rec['type']}**: {rec['message']}")
            with col3:
                st.caption(rec['action'])
        st.markdown("---")