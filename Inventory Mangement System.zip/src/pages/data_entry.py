"""
Data Entry Portal - Main interface for inventory data entry
"""

import streamlit as st
import pandas as pd
from datetime import datetime, date
from src.components.data_entry_forms import (
    show_product_management,
    show_daily_operations,
    show_bulk_upload,
    show_quick_entry
)
from src.services.excel_service import ExcelService
from src.services.data_validation import DataValidator
from src.services.stock_calculator import StockCalculator
from src.components.sidebar import add_alert, update_quick_stats
import config

def show_data_entry():
    """Main data entry page"""
    
    st.header("📝 Data Entry Portal")
    st.markdown("Enter and manage your inventory data efficiently")
    
    # Initialize services
    excel_service = ExcelService()
    validator = DataValidator()
    calculator = StockCalculator()
    
    # Entry mode selection
    entry_mode = st.selectbox(
        "Select Entry Mode",
        [
            "🏢 Daily Operations",
            "📦 Product Management", 
            "⚡ Quick Entry",
            "📄 Bulk Upload",
            "🔄 Stock Adjustments"
        ]
    )
    
    st.markdown("---")
    
    # Route to appropriate entry form
    if entry_mode == "🏢 Daily Operations":
        show_daily_operations_section(excel_service, validator, calculator)
        
    elif entry_mode == "📦 Product Management":
        show_product_management_section(excel_service, validator)
        
    elif entry_mode == "⚡ Quick Entry":
        show_quick_entry_section(excel_service, validator, calculator)
        
    elif entry_mode == "📄 Bulk Upload":
        show_bulk_upload_section(excel_service, validator)
        
    elif entry_mode == "🔄 Stock Adjustments":
        show_stock_adjustment_section(excel_service, validator, calculator)

def show_daily_operations_section(excel_service, validator, calculator):
    """Daily operations entry section"""
    
    st.subheader("🏢 Daily Operations Entry")
    
    # Date selection
    col1, col2 = st.columns([1, 2])
    with col1:
        entry_date = st.date_input(
            "Entry Date",
            value=date.today(),
            max_value=date.today()
        )
    
    with col2:
        operation_type = st.selectbox(
            "Operation Type",
            [
                "Opening Stock",
                "Purchases/Inwards", 
                "Production/Packaging",
                "Sales Entry",
                "Returns Processing",
                "Stock Transfer"
            ]
        )
    
    st.markdown("---")
    
    if operation_type == "Opening Stock":
        show_opening_stock_entry(excel_service, validator, entry_date)
    elif operation_type == "Purchases/Inwards":
        show_purchases_entry(excel_service, validator, entry_date)
    elif operation_type == "Production/Packaging":
        show_packaging_entry(excel_service, validator, entry_date)
    elif operation_type == "Sales Entry":
        show_sales_entry(excel_service, validator, entry_date)
    elif operation_type == "Returns Processing":
        show_returns_entry(excel_service, validator, entry_date)
    elif operation_type == "Stock Transfer":
        show_transfer_entry(excel_service, validator, entry_date)

def show_opening_stock_entry(excel_service, validator, entry_date):
    """Opening stock entry form"""
    
    st.subheader("📊 Opening Stock Entry")
    
    # Load current products
    try:
        current_data = excel_service.read_stock_data()
        products = current_data['Row Labels'].dropna().unique().tolist()
        products = [p for p in products if p != "Roasted chana (kg)"]  # Remove header
    except:
        products = ["0.2", "0.5", "1", "1.5", "2"]  # Default weights
    
    # Entry form
    with st.form("opening_stock_form"):
        st.markdown("**Enter opening stock for each product:**")
        
        entries = []
        for i, product in enumerate(products):
            col1, col2, col3 = st.columns([2, 1, 1])
            
            with col1:
                st.write(f"**Roasted chana {product}kg**")
            
            with col2:
                raw_stock = st.number_input(
                    f"Raw Material (kg)",
                    min_value=0.0,
                    step=0.1,
                    key=f"raw_{i}"
                )
            
            with col3:
                finished_stock = st.number_input(
                    f"Finished Goods (units)",
                    min_value=0,
                    step=1,
                    key=f"finished_{i}"
                )
            
            if raw_stock > 0 or finished_stock > 0:
                entries.append({
                    'product': product,
                    'raw_stock': raw_stock,
                    'finished_stock': finished_stock,
                    'date': entry_date
                })
        
        submitted = st.form_submit_button("💾 Save Opening Stock", use_container_width=True)
        
        if submitted and entries:
            try:
                # Validate entries
                for entry in entries:
                    if not validator.validate_stock_entry(entry):
                        st.error(f"Invalid entry for {entry['product']}kg")
                        return
                
                # Save to Excel
                success = excel_service.update_opening_stock(entries)
                
                if success:
                    st.success(f"✅ Opening stock saved successfully for {len(entries)} products!")
                    add_alert(f"Opening stock updated for {len(entries)} products", "info")
                    
                    # Refresh stats
                    total_stock = sum(e['raw_stock'] + e['finished_stock'] for e in entries)
                    update_quick_stats(total_products=len(entries))
                    
                else:
                    st.error("❌ Failed to save opening stock")
                    add_alert("Opening stock save failed", "error")
                    
            except Exception as e:
                st.error(f"❌ Error: {str(e)}")
                add_alert(f"Opening stock error: {str(e)}", "error")

def show_sales_entry(excel_service, validator, entry_date):
    """Sales entry form"""
    
    st.subheader("💰 Sales Entry")
    
    # Channel selection
    channel = st.selectbox(
        "Sales Channel",
        [
            "Amazon FBA",
            "Amazon Easyship", 
            "Flipkart",
            "Others"
        ]
    )
    
    # Load available products
    try:
        current_data = excel_service.read_stock_data()
        available_products = excel_service.get_available_stock()
    except:
        available_products = {}
    
    with st.form("sales_entry_form"):
        st.markdown(f"**Sales Entry for {channel}**")
        
        sales_entries = []
        
        # Dynamic product selection
        num_products = st.number_input("Number of products to sell", min_value=1, max_value=10, value=1)
        
        for i in range(num_products):
            st.markdown(f"**Product {i+1}**")
            col1, col2, col3, col4 = st.columns([2, 1, 1, 1])
            
            with col1:
                product_weight = st.selectbox(
                    f"Product Weight",
                    ["0.2", "0.5", "1.0", "1.5", "2.0"],
                    key=f"sales_product_{i}"
                )
            
            with col2:
                available = available_products.get(f"{product_weight}kg", 0)
                st.info(f"Available: {available}")
            
            with col3:
                quantity = st.number_input(
                    f"Quantity Sold",
                    min_value=0,
                    max_value=available,
                    step=1,
                    key=f"sales_qty_{i}"
                )
            
            with col4:
                price = st.number_input(
                    f"Unit Price (₹)",
                    min_value=0.0,
                    step=1.0,
                    key=f"sales_price_{i}"
                )
            
            if quantity > 0:
                sales_entries.append({
                    'product_weight': product_weight,
                    'quantity': quantity,
                    'price': price,
                    'channel': channel,
                    'total_value': quantity * price,
                    'date': entry_date
                })
        
        # Order details
        st.markdown("**Order Details**")
        col1, col2 = st.columns(2)
        with col1:
            order_id = st.text_input("Order ID/Reference")
        with col2:
            customer_info = st.text_input("Customer Info (Optional)")
        
        submitted = st.form_submit_button("💾 Record Sales", use_container_width=True)
        
        if submitted and sales_entries:
            try:
                # Validate sales
                total_value = sum(entry['total_value'] for entry in sales_entries)
                
                for entry in sales_entries:
                    if not validator.validate_sales_entry(entry):
                        st.error(f"Invalid sales entry for {entry['product_weight']}kg")
                        return
                
                # Check stock availability
                stock_check = excel_service.check_stock_availability(sales_entries)
                if not stock_check['available']:
                    st.error(f"❌ Insufficient stock: {stock_check['message']}")
                    return
                
                # Save sales
                success = excel_service.record_sales(sales_entries, order_id, customer_info)
                
                if success:
                    st.success(f"✅ Sales recorded successfully! Total: ₹{total_value:,.2f}")
                    add_alert(f"Sales recorded: ₹{total_value:,.2f} via {channel}", "info")
                    
                    # Update stats
                    update_quick_stats(today_sales=total_value)
                    
                    # Show summary
                    st.markdown("**Sales Summary:**")
                    summary_df = pd.DataFrame(sales_entries)
                    st.dataframe(summary_df, use_container_width=True)
                    
                else:
                    st.error("❌ Failed to record sales")
                    add_alert("Sales recording failed", "error")
                    
            except Exception as e:
                st.error(f"❌ Error: {str(e)}")
                add_alert(f"Sales entry error: {str(e)}", "error")

def show_purchases_entry(excel_service, validator, entry_date):
    """Purchases/Inwards entry form"""
    
    st.subheader("📦 Purchases & Inwards")
    
    with st.form("purchases_form"):
        st.markdown("**Purchase Entry**")
        
        col1, col2 = st.columns(2)
        with col1:
            supplier_name = st.text_input("Supplier Name", placeholder="Enter supplier name")
            invoice_number = st.text_input("Invoice Number", placeholder="INV-001")
        
        with col2:
            purchase_date = st.date_input("Purchase Date", value=entry_date)
            total_amount = st.number_input("Total Invoice Amount (₹)", min_value=0.0, step=100.0)
        
        st.markdown("**Items Purchased**")
        
        # Raw material entry
        raw_material_kg = st.number_input(
            "Raw Material Quantity (kg)",
            min_value=0.0,
            step=1.0,
            help="Total weight of raw roasted chana purchased"
        )
        
        raw_material_rate = st.number_input(
            "Rate per kg (₹)",
            min_value=0.0,
            step=1.0
        )
        
        # Packaging materials
        st.markdown("**Packaging Materials**")
        
        packaging_items = []
        num_packaging = st.number_input("Number of packaging items", min_value=0, max_value=5, value=0)
        
        for i in range(num_packaging):
            col1, col2, col3 = st.columns(3)
            with col1:
                item_name = st.text_input(f"Item {i+1} Name", key=f"pack_name_{i}")
            with col2:
                item_qty = st.number_input(f"Quantity", min_value=0, key=f"pack_qty_{i}")
            with col3:
                item_rate = st.number_input(f"Rate (₹)", min_value=0.0, key=f"pack_rate_{i}")
            
            if item_name and item_qty > 0:
                packaging_items.append({
                    'name': item_name,
                    'quantity': item_qty,
                    'rate': item_rate,
                    'total': item_qty * item_rate
                })
        
        notes = st.text_area("Additional Notes", placeholder="Any additional information...")
        
        submitted = st.form_submit_button("💾 Record Purchase", use_container_width=True)
        
        if submitted:
            try:
                purchase_data = {
                    'supplier': supplier_name,
                    'invoice_number': invoice_number,
                    'date': purchase_date,
                    'raw_material_kg': raw_material_kg,
                    'raw_material_rate': raw_material_rate,
                    'raw_material_total': raw_material_kg * raw_material_rate,
                    'packaging_items': packaging_items,
                    'total_amount': total_amount,
                    'notes': notes
                }
                
                # Validate purchase
                if not validator.validate_purchase_entry(purchase_data):
                    st.error("❌ Invalid purchase data")
                    return
                
                # Save purchase
                success = excel_service.record_purchase(purchase_data)
                
                if success:
                    st.success("✅ Purchase recorded successfully!")
                    add_alert(f"Purchase recorded: {supplier_name} - ₹{total_amount:,.2f}", "info")
                    
                    # Show summary
                    st.markdown("**Purchase Summary:**")
                    col1, col2 = st.columns(2)
                    with col1:
                        st.info(f"Raw Material: {raw_material_kg}kg @ ₹{raw_material_rate}/kg")
                    with col2:
                        if packaging_items:
                            st.info(f"Packaging Items: {len(packaging_items)} types")
                
                else:
                    st.error("❌ Failed to record purchase")
                    add_alert("Purchase recording failed", "error")
                    
            except Exception as e:
                st.error(f"❌ Error: {str(e)}")
                add_alert(f"Purchase entry error: {str(e)}", "error")

def show_packaging_entry(excel_service, validator, entry_date):
    """Production/Packaging entry form"""
    
    st.subheader("🏭 Production & Packaging")
    
    with st.form("packaging_form"):
        st.markdown("**Packaging Operation**")
        
        col1, col2 = st.columns(2)
        with col1:
            operator_name = st.text_input("Operator Name")
            shift = st.selectbox("Shift", ["Morning", "Evening", "Night"])
        
        with col2:
            packaging_date = st.date_input("Packaging Date", value=entry_date)
            batch_number = st.text_input("Batch Number", placeholder="BATCH-001")
        
        st.markdown("**Raw Material Consumption**")
        raw_material_used = st.number_input(
            "Raw Material Used (kg)",
            min_value=0.0,
            step=0.1,
            help="Total raw material consumed in this batch"
        )
        
        st.markdown("**Production Output**")
        
        production_entries = []
        
        for weight in ["0.2", "0.5", "1.0", "1.5", "2.0"]:
            col1, col2, col3 = st.columns([1, 1, 1])
            
            with col1:
                st.write(f"**{weight}kg Pouches**")
            
            with col2:
                packets_produced = st.number_input(
                    f"Packets Produced",
                    min_value=0,
                    step=1,
                    key=f"prod_{weight}"
                )
            
            with col3:
                # Calculate weight automatically
                total_weight = packets_produced * float(weight)
                st.info(f"Total: {total_weight}kg")
            
            if packets_produced > 0:
                production_entries.append({
                    'weight': weight,
                    'packets': packets_produced,
                    'total_weight': total_weight
                })
        
        # Quality check
        st.markdown("**Quality Check**")
        col1, col2 = st.columns(2)
        with col1:
            quality_approved = st.selectbox("Quality Status", ["Approved", "Rejected", "Under Review"])
        with col2:
            rejection_reason = st.text_input("Rejection Reason (if any)")
        
        notes = st.text_area("Production Notes")
        
        submitted = st.form_submit_button("💾 Record Production", use_container_width=True)
        
        if submitted and production_entries:
            try:
                production_data = {
                    'operator': operator_name,
                    'shift': shift,
                    'date': packaging_date,
                    'batch_number': batch_number,
                    'raw_material_used': raw_material_used,
                    'production_entries': production_entries,
                    'quality_status': quality_approved,
                    'rejection_reason': rejection_reason,
                    'notes': notes
                }
                
                # Validate production
                if not validator.validate_production_entry(production_data):
                    st.error("❌ Invalid production data")
                    return
                
                # Check raw material availability
                if not excel_service.check_raw_material_availability(raw_material_used):
                    st.error("❌ Insufficient raw material stock")
                    return
                
                # Save production
                success = excel_service.record_production(production_data)
                
                if success:
                    total_packets = sum(entry['packets'] for entry in production_entries)
                    total_weight = sum(entry['total_weight'] for entry in production_entries)
                    
                    st.success(f"✅ Production recorded! {total_packets} packets ({total_weight}kg)")
                    add_alert(f"Production: {total_packets} packets produced", "info")
                    
                    # Show production summary
                    st.markdown("**Production Summary:**")
                    summary_df = pd.DataFrame(production_entries)
                    st.dataframe(summary_df, use_container_width=True)
                
                else:
                    st.error("❌ Failed to record production")
                    add_alert("Production recording failed", "error")
                    
            except Exception as e:
                st.error(f"❌ Error: {str(e)}")
                add_alert(f"Production entry error: {str(e)}", "error")

def show_returns_entry(excel_service, validator, entry_date):
    """Returns processing entry"""
    
    st.subheader("🔄 Returns Processing")
    
    with st.form("returns_form"):
        st.markdown("**Return Details**")
        
        col1, col2 = st.columns(2)
        with col1:
            return_channel = st.selectbox(
                "Return Channel",
                ["Amazon FBA", "Amazon Easyship", "Flipkart", "Others"]
            )
            return_reason = st.selectbox(
                "Return Reason",
                [
                    "Customer Return",
                    "Damaged in Transit", 
                    "Quality Issue",
                    "Wrong Product",
                    "Expired Product",
                    "Other"
                ]
            )
        
        with col2:
            return_date = st.date_input("Return Date", value=entry_date)
            return_id = st.text_input("Return ID/Reference")
        
        st.markdown("**Returned Items**")
        
        return_entries = []
        num_items = st.number_input("Number of returned items", min_value=1, max_value=10, value=1)
        
        for i in range(num_items):
            st.markdown(f"**Item {i+1}**")
            col1, col2, col3, col4 = st.columns(4)
            
            with col1:
                product_weight = st.selectbox(
                    f"Product Weight",
                    ["0.2", "0.5", "1.0", "1.5", "2.0"],
                    key=f"return_product_{i}"
                )
            
            with col2:
                quantity_returned = st.number_input(
                    f"Quantity",
                    min_value=0,
                    step=1,
                    key=f"return_qty_{i}"
                )
            
            with col3:
                condition = st.selectbox(
                    f"Condition",
                    ["Good", "Damaged", "Expired"],
                    key=f"return_condition_{i}"
                )
            
            with col4:
                action = st.selectbox(
                    f"Action",
                    ["Restock", "Discard", "Repair", "Hold"],
                    key=f"return_action_{i}"
                )
            
            if quantity_returned > 0:
                return_entries.append({
                    'product_weight': product_weight,
                    'quantity': quantity_returned,
                    'condition': condition,
                    'action': action,
                    'channel': return_channel,
                    'reason': return_reason,
                    'date': return_date
                })
        
        notes = st.text_area("Additional Notes about the return")
        
        submitted = st.form_submit_button("💾 Process Returns", use_container_width=True)
        
        if submitted and return_entries:
            try:
                return_data = {
                    'return_id': return_id,
                    'channel': return_channel,
                    'reason': return_reason,
                    'date': return_date,
                    'entries': return_entries,
                    'notes': notes
                }
                
                # Validate returns
                if not validator.validate_return_entry(return_data):
                    st.error("❌ Invalid return data")
                    return
                
                # Process returns
                success = excel_service.process_returns(return_data)
                
                if success:
                    total_items = sum(entry['quantity'] for entry in return_entries)
                    good_items = sum(entry['quantity'] for entry in return_entries if entry['condition'] == 'Good')
                    
                    st.success(f"✅ Returns processed! {total_items} items ({good_items} good)")
                    add_alert(f"Returns processed: {total_items} items from {return_channel}", "info")
                    
                    # Show returns summary
                    st.markdown("**Returns Summary:**")
                    summary_df = pd.DataFrame(return_entries)
                    st.dataframe(summary_df, use_container_width=True)
                
                else:
                    st.error("❌ Failed to process returns")
                    add_alert("Returns processing failed", "error")
                    
            except Exception as e:
                st.error(f"❌ Error: {str(e)}")
                add_alert(f"Returns entry error: {str(e)}", "error")

def show_stock_adjustment_section(excel_service, validator, calculator):
    """Stock adjustment section"""
    
    st.subheader("🔄 Stock Adjustments")
    st.info("Use this section to correct stock discrepancies found during physical verification")
    
    with st.form("stock_adjustment_form"):
        st.markdown("**Adjustment Details**")
        
        col1, col2 = st.columns(2)
        with col1:
            adjustment_date = st.date_input("Adjustment Date", value=date.today())
            adjustment_reason = st.selectbox(
                "Reason for Adjustment",
                [
                    "Physical Count Difference",
                    "Damage/Wastage",
                    "System Error Correction",
                    "Theft/Loss",
                    "Quality Rejection",
                    "Other"
                ]
            )
        
        with col2:
            authorized_by = st.text_input("Authorized By")
            reference_number = st.text_input("Reference Number")
        
        st.markdown("**Stock Adjustments**")
        
        adjustments = []
        
        for weight in ["0.2", "0.5", "1.0", "1.5", "2.0"]:
            st.markdown(f"**{weight}kg Roasted Chana**")
            col1, col2, col3, col4 = st.columns(4)
            
            with col1:
                try:
                    current_stock = excel_service.get_current_stock(f"{weight}kg")
                    st.info(f"Current: {current_stock}")
                except:
                    current_stock = 0
                    st.warning("Cannot fetch current stock")
            
            with col2:
                physical_count = st.number_input(
                    f"Physical Count",
                    min_value=0,
                    step=1,
                    key=f"physical_{weight}"
                )
            
            with col3:
                difference = physical_count - current_stock
                if difference != 0:
                    color = "red" if difference < 0 else "green"
                    st.markdown(f"<span style='color: {color}'>Diff: {difference:+d}</span>", 
                              unsafe_allow_html=True)
                else:
                    st.success("No difference")
            
            with col4:
                if difference != 0:
                    apply_adjustment = st.checkbox(f"Apply", key=f"apply_{weight}")
                    
                    if apply_adjustment:
                        adjustments.append({
                            'product_weight': weight,
                            'current_stock': current_stock,
                            'physical_count': physical_count,
                            'adjustment': difference
                        })
        
        notes = st.text_area("Adjustment Notes", placeholder="Explain the reason for adjustments...")
        
        submitted = st.form_submit_button("💾 Apply Adjustments", use_container_width=True)
        
        if submitted and adjustments:
            try:
                adjustment_data = {
                    'date': adjustment_date,
                    'reason': adjustment_reason,
                    'authorized_by': authorized_by,
                    'reference_number': reference_number,
                    'adjustments': adjustments,
                    'notes': notes
                }
                
                # Validate adjustments
                if not validator.validate_stock_adjustment(adjustment_data):
                    st.error("❌ Invalid adjustment data")
                    return
                
                # Apply adjustments
                success = excel_service.apply_stock_adjustments(adjustment_data)
                
                if success:
                    total_adjustments = len(adjustments)
                    st.success(f"✅ Stock adjustments applied for {total_adjustments} products!")
                    add_alert(f"Stock adjustments applied: {total_adjustments} products", "warning")
                    
                    # Show adjustment summary
                    st.markdown("**Adjustment Summary:**")
                    summary_df = pd.DataFrame(adjustments)
                    st.dataframe(summary_df, use_container_width=True)
                
                else:
                    st.error("❌ Failed to apply stock adjustments")
                    add_alert("Stock adjustment failed", "error")
                    
            except Exception as e:
                st.error(f"❌ Error: {str(e)}")
                add_alert(f"Stock adjustment error: {str(e)}", "error")

def show_product_management_section(excel_service, validator):
    """Product management section"""
    show_product_management()

def show_quick_entry_section(excel_service, validator, calculator):
    """Quick entry section"""
    show_quick_entry()

def show_bulk_upload_section(excel_service, validator):
    """Bulk upload section"""
    show_bulk_upload()